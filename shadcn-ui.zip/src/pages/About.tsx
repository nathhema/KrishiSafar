import { MainLayout } from "@/components/layout/main-layout";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Heart, Leaf, Sprout, Users } from "lucide-react";

export default function AboutPage() {
  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="relative py-20 bg-nature-50 border-b border-nature-100">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-semibold mb-6">Our Story</h1>
            <p className="text-xl text-muted-foreground mb-8">
              KrishiSafar began with a simple idea: to reconnect urban youth with their rural roots and promote sustainable travel.
            </p>
          </div>
        </div>
        
        <div className="absolute bottom-0 left-0 w-full overflow-hidden">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none" className="h-16 w-full text-white">
            <path d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V120H0V95.8C59.71,118.11,165.07,111.28,321.39,56.44Z" fill="currentColor"></path>
          </svg>
        </div>
      </section>
      
      {/* Mission Section */}
      <section className="py-16">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <img 
                src="/assets/images/mission.jpg" 
                alt="Our mission"
                className="rounded-lg shadow-natural h-full object-cover"
              />
            </div>
            <div className="space-y-6">
              <div className="inline-block rounded-lg bg-nature-100 px-3 py-1 text-sm text-nature-700 font-medium">
                Our Mission
              </div>
              <h2 className="text-3xl font-medium">Connecting Urban India with Rural Roots</h2>
              <p className="text-lg text-muted-foreground">
                At KrishiSafar, we're on a mission to bridge the growing disconnect between urban India and its agricultural heritage. By creating a platform that facilitates meaningful interactions between city dwellers and rural communities, we aim to foster mutual understanding, appreciation, and support.
              </p>
              <p className="text-muted-foreground">
                Our curated farm stays and nature retreats provide urban youth with authentic rural experiences while supporting local farmers and communities. We believe in sustainable tourism that respects local cultures, promotes environmental conservation, and creates economic opportunities for rural areas.
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Values Section */}
      <section className="py-16 bg-nature-50 border-y border-nature-100">
        <div className="container">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-3xl font-medium mb-4">Our Values</h2>
            <p className="text-muted-foreground">
              At the heart of everything we do are our core values that drive our mission and shape our approach to connecting urban and rural India.
            </p>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white p-6 rounded-lg border border-nature-100 shadow-soft flex flex-col items-center text-center">
              <div className="bg-nature-100 p-3 rounded-full mb-4">
                <Sprout className="w-6 h-6 text-nature-600" />
              </div>
              <h3 className="text-xl font-medium mb-2">Sustainability</h3>
              <p className="text-muted-foreground">
                We promote environmentally responsible practices and support sustainable agriculture and tourism.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg border border-nature-100 shadow-soft flex flex-col items-center text-center">
              <div className="bg-nature-100 p-3 rounded-full mb-4">
                <Users className="w-6 h-6 text-nature-600" />
              </div>
              <h3 className="text-xl font-medium mb-2">Community</h3>
              <p className="text-muted-foreground">
                We believe in creating meaningful connections and fostering a sense of belonging between diverse communities.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg border border-nature-100 shadow-soft flex flex-col items-center text-center">
              <div className="bg-nature-100 p-3 rounded-full mb-4">
                <Leaf className="w-6 h-6 text-nature-600" />
              </div>
              <h3 className="text-xl font-medium mb-2">Authenticity</h3>
              <p className="text-muted-foreground">
                We provide genuine experiences that respect and celebrate India's rich agricultural heritage and rural traditions.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg border border-nature-100 shadow-soft flex flex-col items-center text-center">
              <div className="bg-nature-100 p-3 rounded-full mb-4">
                <Heart className="w-6 h-6 text-nature-600" />
              </div>
              <h3 className="text-xl font-medium mb-2">Empowerment</h3>
              <p className="text-muted-foreground">
                We strive to create economic opportunities for rural communities while enriching the lives of urban travelers.
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Team Section */}
      <section className="py-16">
        <div className="container">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-3xl font-medium mb-4">Meet Our Team</h2>
            <p className="text-muted-foreground">
              A passionate group of individuals dedicated to bridging the urban-rural divide and promoting sustainable tourism.
            </p>
          </div>
          
          <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((member) => (
              <div key={member} className="bg-white rounded-lg border border-nature-100 overflow-hidden hover-lift">
                <div className="aspect-square overflow-hidden">
                  <img 
                    src={`/assets/images/team-${member}.jpg`} 
                    alt={`Team member ${member}`}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-4 text-center">
                  <h3 className="font-medium text-lg">Team Member {member}</h3>
                  <p className="text-sm text-nature-600">Co-Founder</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Join Us Section */}
      <section className="py-16 bg-nature-600">
        <div className="container">
          <div className="text-center max-w-2xl mx-auto">
            <h2 className="text-3xl font-medium text-white mb-4">Join Our Journey</h2>
            <p className="text-nature-100 mb-8">
              Be a part of our mission to reconnect urban India with its rural roots and promote sustainable tourism.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild className="bg-white text-nature-700 hover:bg-nature-100">
                <Link to="/careers">Join Our Team</Link>
              </Button>
              <Button asChild variant="outline" className="border-white text-white hover:bg-nature-700">
                <Link to="/contact">Contact Us</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </MainLayout>
  );
}
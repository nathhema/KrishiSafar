import { MainLayout } from "@/components/layout/main-layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { CalendarIcon, Leaf, Map, Search, Users, X } from "lucide-react";
import { useState } from "react";

// Mock data for stays
const allStays = [
  {
    id: 1,
    name: "Sunset Valley Farm Retreat",
    location: "Himachal Pradesh",
    price: 2500,
    rating: 4.9,
    image: "/assets/images/farm-retreat.jpg",
    tags: ["Farm Stay", "Mountains"],
    features: ["Organic Farm", "Mountain Views", "Hiking Trails"]
  },
  {
    id: 2,
    name: "Green Meadows Eco Lodge",
    location: "Kerala",
    price: 3200,
    rating: 4.8,
    image: "/assets/images/eco-lodge.jpg",
    tags: ["Eco-friendly", "Waterfront"],
    features: ["Solar Powered", "Lake Access", "Organic Meals"]
  },
  {
    id: 3,
    name: "Organic Orchard Homestay",
    location: "Karnataka",
    price: 1800,
    rating: 4.7,
    image: "/assets/images/orchard-homestay.jpg",
    tags: ["Organic Farm", "Family-friendly"],
    features: ["Fruit Picking", "Farm Activities", "Kids Play Area"]
  },
  {
    id: 4,
    name: "Mountain View Cottage",
    location: "Uttarakhand",
    price: 2800,
    rating: 4.9,
    image: "/assets/images/mountain-cottage.jpg",
    tags: ["Mountain View", "Hiking"],
    features: ["Panoramic Views", "Trekking", "Campfire"]
  },
  {
    id: 5,
    name: "Riverside Farm Cabin",
    location: "Madhya Pradesh",
    price: 2200,
    rating: 4.6,
    image: "/assets/images/farm-cabin.jpg",
    tags: ["Riverside", "Peaceful"],
    features: ["River Access", "Fishing", "Organic Vegetables"]
  },
  {
    id: 6,
    name: "Tea Garden Bungalow",
    location: "West Bengal",
    price: 3500,
    rating: 4.8,
    image: "/assets/images/tea-bungalow.jpg",
    tags: ["Tea Plantation", "Heritage"],
    features: ["Tea Tours", "Colonial Architecture", "Guided Walks"]
  },
  {
    id: 7,
    name: "Spice Farm Retreat",
    location: "Goa",
    price: 2700,
    rating: 4.7,
    image: "/assets/images/spice-farm.jpg",
    tags: ["Spice Farm", "Cultural"],
    features: ["Spice Tours", "Cooking Classes", "Swimming Pool"]
  },
  {
    id: 8,
    name: "Bamboo Forest Eco Huts",
    location: "Assam",
    price: 1900,
    rating: 4.5,
    image: "/assets/images/bamboo-huts.jpg",
    tags: ["Eco-friendly", "Forest"],
    features: ["Bamboo Architecture", "Bird Watching", "Nature Walks"]
  }
];

export default function StaysPage() {
  const [priceRange, setPriceRange] = useState<[number, number]>([1000, 5000]);
  const [searchTerm, setSearchTerm] = useState("");
  const [activeFilters, setActiveFilters] = useState<string[]>([]);

  // Filter stays based on search term, price range and active filters
  const filteredStays = allStays.filter(stay => {
    const matchesSearch = stay.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          stay.location.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesPrice = stay.price >= priceRange[0] && stay.price <= priceRange[1];
    
    const matchesFilters = activeFilters.length === 0 || 
                           stay.tags.some(tag => activeFilters.includes(tag)) ||
                           stay.features.some(feature => activeFilters.includes(feature));
    
    return matchesSearch && matchesPrice && matchesFilters;
  });

  // Add or remove a filter
  const toggleFilter = (filter: string) => {
    if (activeFilters.includes(filter)) {
      setActiveFilters(activeFilters.filter(f => f !== filter));
    } else {
      setActiveFilters([...activeFilters, filter]);
    }
  };

  // Clear all filters
  const clearFilters = () => {
    setPriceRange([1000, 5000]);
    setSearchTerm("");
    setActiveFilters([]);
  };

  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="relative py-12 bg-nature-700">
        <div className="container">
          <div className="max-w-3xl text-white">
            <h1 className="text-4xl font-semibold mb-4">Find Your Perfect Nature Stay</h1>
            <p className="text-lg text-nature-100 mb-8">
              Discover authentic farm stays, eco-retreats, and immersive experiences across India
            </p>
          </div>
        </div>
      </section>
      
      {/* Search and Filter Section */}
      <section className="bg-white border-b border-nature-100 sticky top-16 z-30">
        <div className="container py-4">
          <div className="flex flex-wrap items-center gap-4">
            {/* Search Input */}
            <div className="flex-1 min-w-[200px]">
              <div className="flex items-center border border-nature-200 rounded-lg p-2 bg-white focus-within:ring-1 focus-within:ring-primary">
                <Search className="w-5 h-5 text-muted-foreground mr-2" />
                <Input 
                  className="border-0 focus-visible:ring-0 p-0" 
                  placeholder="Search for stays or locations"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                {searchTerm && (
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-5 w-5 p-0 text-muted-foreground"
                    onClick={() => setSearchTerm("")}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </div>
            
            {/* Filters */}
            <div className="flex flex-wrap gap-2 items-center">
              <Select>
                <SelectTrigger className="w-[150px] border-nature-200">
                  <SelectValue placeholder="Accommodation Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="farm-stay">Farm Stays</SelectItem>
                  <SelectItem value="eco-retreat">Eco Retreats</SelectItem>
                  <SelectItem value="homestay">Homestays</SelectItem>
                  <SelectItem value="cottage">Cottages</SelectItem>
                </SelectContent>
              </Select>
              
              <Select>
                <SelectTrigger className="w-[150px] border-nature-200">
                  <SelectValue placeholder="Location" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="north">North India</SelectItem>
                  <SelectItem value="south">South India</SelectItem>
                  <SelectItem value="east">East India</SelectItem>
                  <SelectItem value="west">West India</SelectItem>
                  <SelectItem value="central">Central India</SelectItem>
                </SelectContent>
              </Select>
              
              <Button 
                variant="outline" 
                className="border-nature-200"
                onClick={clearFilters}
              >
                Clear Filters
              </Button>
            </div>
          </div>
          
          {/* Active filters */}
          {activeFilters.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-3">
              {activeFilters.map(filter => (
                <div 
                  key={filter}
                  className="bg-nature-100 text-nature-700 text-sm px-3 py-1 rounded-full flex items-center gap-1"
                >
                  {filter}
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-4 w-4 p-0 hover:bg-transparent"
                    onClick={() => toggleFilter(filter)}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              ))}
              
              <Button 
                variant="ghost" 
                className="text-sm text-nature-600 h-6 px-2"
                onClick={clearFilters}
              >
                Clear All
              </Button>
            </div>
          )}
        </div>
      </section>
      
      <div className="container py-8">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Sidebar with filters */}
          <div className="lg:w-1/4 space-y-6">
            <Card className="border-nature-100">
              <CardContent className="p-4">
                <h3 className="text-lg font-medium mb-4">Filters</h3>
                
                <Accordion type="multiple" className="space-y-2">
                  <AccordionItem value="price" className="border-nature-100">
                    <AccordionTrigger className="py-2 text-sm font-medium hover:no-underline">
                      Price Range
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-4 pt-2">
                        <Slider 
                          value={priceRange}
                          min={1000}
                          max={5000}
                          step={100}
                          onValueChange={(value) => setPriceRange(value as [number, number])}
                          className="py-4"
                        />
                        <div className="flex justify-between text-sm">
                          <span>₹{priceRange[0]}</span>
                          <span>₹{priceRange[1]}</span>
                        </div>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                  
                  <AccordionItem value="amenities" className="border-nature-100">
                    <AccordionTrigger className="py-2 text-sm font-medium hover:no-underline">
                      Amenities
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-2">
                        {["Swimming Pool", "WiFi", "Organic Meals", "Farm Activities", "Mountain Views", "Hiking Trails"].map((amenity) => (
                          <div key={amenity} className="flex items-center space-x-2">
                            <Checkbox 
                              id={amenity.toLowerCase().replace(/\s/g, '-')}
                              checked={activeFilters.includes(amenity)}
                              onCheckedChange={() => toggleFilter(amenity)}
                            />
                            <label 
                              htmlFor={amenity.toLowerCase().replace(/\s/g, '-')} 
                              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              {amenity}
                            </label>
                          </div>
                        ))}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                  
                  <AccordionItem value="property-type" className="border-nature-100">
                    <AccordionTrigger className="py-2 text-sm font-medium hover:no-underline">
                      Property Type
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-2">
                        {["Farm Stay", "Eco-friendly", "Riverside", "Mountain View", "Heritage", "Forest"].map((type) => (
                          <div key={type} className="flex items-center space-x-2">
                            <Checkbox 
                              id={type.toLowerCase().replace(/\s/g, '-')}
                              checked={activeFilters.includes(type)}
                              onCheckedChange={() => toggleFilter(type)}
                            />
                            <label 
                              htmlFor={type.toLowerCase().replace(/\s/g, '-')} 
                              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              {type}
                            </label>
                          </div>
                        ))}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </CardContent>
            </Card>
          </div>
          
          {/* Main content with stays listing */}
          <div className="lg:w-3/4">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-medium">
                {filteredStays.length} {filteredStays.length === 1 ? 'stay' : 'stays'} available
              </h2>
              <Select defaultValue="recommended">
                <SelectTrigger className="w-[180px] border-nature-200">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="recommended">Recommended</SelectItem>
                  <SelectItem value="price-low">Price: Low to High</SelectItem>
                  <SelectItem value="price-high">Price: High to Low</SelectItem>
                  <SelectItem value="rating">Rating: High to Low</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredStays.map((stay) => (
                <Card key={stay.id} className="border-nature-100 overflow-hidden group hover-lift">
                  <div className="aspect-[4/3] relative overflow-hidden">
                    <div className="absolute inset-0 bg-nature-800/20 group-hover:bg-nature-800/10 transition-colors z-10" />
                    <img 
                      src={stay.image || "https://placehold.co/400x300?text=KrishiSafar"} 
                      alt={stay.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    />
                    <div className="absolute top-3 left-3 flex gap-2 z-20">
                      {stay.tags.map((tag, idx) => (
                        <span key={idx} className="text-xs bg-white/90 backdrop-blur-sm px-2 py-1 rounded-full text-nature-800 font-medium">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                  <CardContent className="p-5">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-medium text-lg">{stay.name}</h3>
                      <div className="flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 text-amber-400">
                          <path fillRule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z" clipRule="evenodd" />
                        </svg>
                        <span className="text-sm font-medium ml-1">{stay.rating}</span>
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground flex items-center mb-3">
                      <Map className="w-4 h-4 mr-1" strokeWidth={1.5} />
                      {stay.location}
                    </p>
                    <ul className="text-sm text-muted-foreground mb-3 space-y-1">
                      {stay.features.map((feature, idx) => (
                        <li key={idx} className="flex items-center gap-2">
                          <Leaf className="w-3 h-3 text-nature-500" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                    <div className="flex justify-between items-center mt-4">
                      <div>
                        <span className="font-semibold">₹{stay.price}</span>
                        <span className="text-sm text-muted-foreground">/night</span>
                      </div>
                      <Button 
                        size="sm" 
                        className="bg-nature-600 hover:bg-nature-700 text-white"
                        onClick={() => window.location.href = "/stays/farm-123"}
                      >
                        View Details
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            
            {filteredStays.length === 0 && (
              <div className="text-center py-12">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-nature-100 mb-4">
                  <Leaf className="w-8 h-8 text-nature-600" />
                </div>
                <h3 className="text-xl font-medium mb-2">No stays found</h3>
                <p className="text-muted-foreground mb-6">
                  We couldn't find any stays matching your current filters.
                </p>
                <Button 
                  variant="outline" 
                  className="border-nature-200"
                  onClick={clearFilters}
                >
                  Clear All Filters
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Join Community Section */}
      <section className="bg-nature-50 border-t border-nature-100 py-16">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-medium mb-4">Join Our Community</h2>
            <p className="text-lg text-muted-foreground mb-8">
              Connect with like-minded travelers and get exclusive access to special offers and unique stays.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild className="bg-nature-600 hover:bg-nature-700 text-white">
                <a href="#">Sign Up Now</a>
              </Button>
              <Button asChild variant="outline" className="border-nature-600 text-nature-700 hover:bg-nature-50">
                <a href="#">Learn More</a>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </MainLayout>
  );
}
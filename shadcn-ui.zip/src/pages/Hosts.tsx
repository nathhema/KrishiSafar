import { MainLayout } from "@/components/layout/main-layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Check, ChevronRight, Clock, HandCoins, Heart, Shield, Users } from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export default function HostsPage() {
  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="relative py-20 bg-nature-600">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div className="text-white space-y-6 max-w-lg">
              <h1 className="text-4xl md:text-5xl font-semibold leading-tight">Share Your Rural Knowledge & Earn</h1>
              <p className="text-nature-100 text-lg">
                Turn your skills, traditions, and cultural knowledge into memorable experiences for travelers while creating a sustainable income stream.
              </p>
              <Button asChild size="lg" className="text-lg bg-white text-nature-700 hover:bg-nature-50">
                <a href="#get-started">Become a Host</a>
              </Button>
            </div>
            
            <div className="relative">
              <div className="rounded-lg overflow-hidden shadow-xl">
                <img 
                  src="/assets/images/host-hero.jpg" 
                  alt="Local hosts sharing experiences"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
        
        <div className="absolute bottom-0 left-0 w-full overflow-hidden">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none" className="h-16 w-full text-white">
            <path d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V120H0V95.8C59.71,118.11,165.07,111.28,321.39,56.44Z" fill="currentColor"></path>
          </svg>
        </div>
      </section>
      
      {/* Benefits Section */}
      <section className="py-16">
        <div className="container">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-3xl font-medium mb-4">Why Host on KrishiSafar?</h2>
            <p className="text-lg text-muted-foreground">
              Join our growing community of hosts who are sharing their skills and knowledge while creating sustainable income.
            </p>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="border-nature-100 hover-lift">
              <CardContent className="p-6 flex flex-col items-start">
                <div className="bg-nature-100 p-3 rounded-full mb-4">
                  <HandCoins className="w-6 h-6 text-nature-600" />
                </div>
                <h3 className="text-xl font-medium mb-2">Earn Extra Income</h3>
                <p className="text-muted-foreground mb-4">
                  Create a reliable secondary income stream by sharing your skills and knowledge with interested travelers.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2 text-sm">
                    <Check className="w-4 h-4 text-nature-600" />
                    <span>Set your own prices and availability</span>
                  </li>
                  <li className="flex items-center gap-2 text-sm">
                    <Check className="w-4 h-4 text-nature-600" />
                    <span>Receive payments directly to your bank account</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
            
            <Card className="border-nature-100 hover-lift">
              <CardContent className="p-6 flex flex-col items-start">
                <div className="bg-nature-100 p-3 rounded-full mb-4">
                  <Heart className="w-6 h-6 text-nature-600" />
                </div>
                <h3 className="text-xl font-medium mb-2">Preserve Traditions</h3>
                <p className="text-muted-foreground mb-4">
                  Pass down your cultural heritage and traditional knowledge to the next generation of enthusiasts.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2 text-sm">
                    <Check className="w-4 h-4 text-nature-600" />
                    <span>Document and share traditional practices</span>
                  </li>
                  <li className="flex items-center gap-2 text-sm">
                    <Check className="w-4 h-4 text-nature-600" />
                    <span>Create cultural exchange opportunities</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
            
            <Card className="border-nature-100 hover-lift">
              <CardContent className="p-6 flex flex-col items-start">
                <div className="bg-nature-100 p-3 rounded-full mb-4">
                  <Users className="w-6 h-6 text-nature-600" />
                </div>
                <h3 className="text-xl font-medium mb-2">Build Community</h3>
                <p className="text-muted-foreground mb-4">
                  Connect with like-minded individuals and create meaningful relationships with guests from around the world.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2 text-sm">
                    <Check className="w-4 h-4 text-nature-600" />
                    <span>Join our network of rural hosts</span>
                  </li>
                  <li className="flex items-center gap-2 text-sm">
                    <Check className="w-4 h-4 text-nature-600" />
                    <span>Access community resources and support</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
      
      {/* What You Can Host */}
      <section className="py-16 bg-nature-50 border-y border-nature-100">
        <div className="container">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-3xl font-medium mb-4">What You Can Host</h2>
            <p className="text-lg text-muted-foreground">
              Share your unique skills and knowledge with eager travelers looking for authentic experiences.
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="bg-white rounded-lg p-6 text-center border border-nature-100 shadow-soft">
              <div className="mx-auto w-16 h-16 bg-nature-100 rounded-full flex items-center justify-center mb-4">
                <img src="/assets/images/icons/farming.svg" alt="Farming Icon" className="w-8 h-8" />
              </div>
              <h3 className="font-medium mb-2">Farming Workshops</h3>
              <p className="text-sm text-muted-foreground">
                Organic farming, permaculture, and traditional agricultural methods
              </p>
            </div>
            
            <div className="bg-white rounded-lg p-6 text-center border border-nature-100 shadow-soft">
              <div className="mx-auto w-16 h-16 bg-nature-100 rounded-full flex items-center justify-center mb-4">
                <img src="/assets/images/icons/cooking.svg" alt="Cooking Icon" className="w-8 h-8" />
              </div>
              <h3 className="font-medium mb-2">Culinary Experiences</h3>
              <p className="text-sm text-muted-foreground">
                Traditional cooking classes, harvest-to-table meals, and food preservation
              </p>
            </div>
            
            <div className="bg-white rounded-lg p-6 text-center border border-nature-100 shadow-soft">
              <div className="mx-auto w-16 h-16 bg-nature-100 rounded-full flex items-center justify-center mb-4">
                <img src="/assets/images/icons/craft.svg" alt="Craft Icon" className="w-8 h-8" />
              </div>
              <h3 className="font-medium mb-2">Traditional Crafts</h3>
              <p className="text-sm text-muted-foreground">
                Pottery, weaving, wood carving, and other artisanal skills
              </p>
            </div>
            
            <div className="bg-white rounded-lg p-6 text-center border border-nature-100 shadow-soft">
              <div className="mx-auto w-16 h-16 bg-nature-100 rounded-full flex items-center justify-center mb-4">
                <img src="/images/Nature.jpg" alt="Nature Icon" className="w-8 h-8" />
              </div>
              <h3 className="font-medium mb-2">Nature Experiences</h3>
              <p className="text-sm text-muted-foreground">
                Guided walks, wildlife spotting, and medicinal plant identification
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* How It Works */}
      <section className="py-16">
        <div className="container">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-3xl font-medium mb-4">How It Works</h2>
            <p className="text-lg text-muted-foreground">
              Getting started as a host is simple and straightforward.
            </p>
          </div>
          
          <div className="max-w-4xl mx-auto">
            <div className="grid md:grid-cols-3 gap-8">
              <div className="flex flex-col items-center text-center">
                <div className="relative">
                  <div className="bg-nature-100 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                    <span className="text-xl font-semibold text-nature-700">1</span>
                  </div>
                  <div className="hidden md:block absolute top-8 left-full w-full h-0.5 bg-nature-200">
                    <ChevronRight className="text-nature-300 absolute -right-4 -top-2" />
                  </div>
                </div>
                <h3 className="font-medium mb-2">Apply to Host</h3>
                <p className="text-sm text-muted-foreground">
                  Fill out our simple application form telling us about your experience and what you'd like to share.
                </p>
              </div>
              
              <div className="flex flex-col items-center text-center">
                <div className="relative">
                  <div className="bg-nature-100 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                    <span className="text-xl font-semibold text-nature-700">2</span>
                  </div>
                  <div className="hidden md:block absolute top-8 left-full w-full h-0.5 bg-nature-200">
                    <ChevronRight className="text-nature-300 absolute -right-4 -top-2" />
                  </div>
                </div>
                <h3 className="font-medium mb-2">Create Your Experience</h3>
                <p className="text-sm text-muted-foreground">
                  Work with our team to design a compelling experience that showcases your skills and knowledge.
                </p>
              </div>
              
              <div className="flex flex-col items-center text-center">
                <div className="bg-nature-100 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                  <span className="text-xl font-semibold text-nature-700">3</span>
                </div>
                <h3 className="font-medium mb-2">Welcome Guests</h3>
                <p className="text-sm text-muted-foreground">
                  Start hosting visitors and earning income while sharing your passion and knowledge.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Host Success Stories */}
      <section className="py-16 bg-nature-700 text-white">
        <div className="container">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-3xl font-medium mb-4">Success Stories</h2>
            <p className="text-lg text-nature-100">
              Hear from our hosts about their experience with KrishiSafar.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="w-16 h-16 rounded-full overflow-hidden flex-shrink-0">
                    <img src="/assets/images/testimonials/host-1.jpg" alt="Host" className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <p className="text-lg mb-4">
                      "Hosting farming workshops on KrishiSafar has allowed me to share my passion for organic farming while creating a sustainable income stream. The platform has been instrumental in connecting me with people who are genuinely interested in learning traditional agricultural practices."
                    </p>
                    <div>
                      <p className="font-medium">Rajesh Kumar</p>
                      <p className="text-sm text-nature-200">Organic Farmer, Uttarakhand</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="w-16 h-16 rounded-full overflow-hidden flex-shrink-0">
                    <img src="/assets/images/testimonials/host-2.jpg" alt="Host" className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <p className="text-lg mb-4">
                      "As a traditional weaver, I was concerned about our craft dying out. Through KrishiSafar, I've been able to host weaving workshops that not only provide income but help preserve our cultural heritage by passing these skills on to interested visitors."
                    </p>
                    <div>
                      <p className="font-medium">Lakshmi Devi</p>
                      <p className="text-sm text-nature-200">Artisanal Weaver, Karnataka</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
      
      {/* FAQ Section */}
      <section className="py-16">
        <div className="container">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-3xl font-medium mb-4">Frequently Asked Questions</h2>
            <p className="text-lg text-muted-foreground">
              Get answers to common questions about hosting with KrishiSafar.
            </p>
          </div>
          
          <div className="max-w-3xl mx-auto">
            <Accordion type="single" collapsible className="space-y-4">
              <AccordionItem value="item-1" className="border border-nature-200 rounded-lg px-6">
                <AccordionTrigger className="text-lg font-medium">
                  Who can become a host?
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground">
                  Anyone with knowledge of traditional farming practices, culinary skills, crafts, or cultural experiences from rural India can apply to become a host. We particularly welcome applications from farmers, artisans, and community elders who want to share their skills and knowledge.
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="item-2" className="border border-nature-200 rounded-lg px-6">
                <AccordionTrigger className="text-lg font-medium">
                  How much can I earn as a host?
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground">
                  Earnings vary based on the type of experience you offer, its duration, and frequency. Many of our hosts earn between ₹5,000-₹20,000 per month by hosting 1-2 experiences weekly. You set your own prices, and we take a small service fee to maintain the platform.
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="item-3" className="border border-nature-200 rounded-lg px-6">
                <AccordionTrigger className="text-lg font-medium">
                  Do I need special equipment or facilities?
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground">
                  This depends on the type of experience you wish to host. Some experiences may require basic equipment or facilities, while others may simply need your knowledge and guidance. Our team will work with you to determine what's needed and how to optimize your experience for guests.
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="item-4" className="border border-nature-200 rounded-lg px-6">
                <AccordionTrigger className="text-lg font-medium">
                  How often do I need to host experiences?
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground">
                  You have complete control over your availability. Some hosts offer experiences daily, while others may host only on weekends or during certain seasons. You can update your availability through our easy-to-use host dashboard.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </div>
      </section>
      
      {/* Get Started Form */}
      <section id="get-started" className="py-16 bg-nature-50 border-t border-nature-100">
        <div className="container">
          <div className="grid md:grid-cols-5 gap-10 items-center">
            <div className="md:col-span-2 space-y-6">
              <h2 className="text-3xl font-medium">Ready to Start Hosting?</h2>
              <p className="text-lg text-muted-foreground">
                Apply today to join our growing community of hosts sharing rural experiences and traditions.
              </p>
              
              <div className="space-y-4">
                <div className="flex gap-3 items-start">
                  <div className="bg-nature-100 p-2 rounded-full">
                    <Shield className="w-5 h-5 text-nature-600" />
                  </div>
                  <div>
                    <h3 className="font-medium">Verified Guests</h3>
                    <p className="text-sm text-muted-foreground">
                      All guests are verified for your safety and security.
                    </p>
                  </div>
                </div>
                
                <div className="flex gap-3 items-start">
                  <div className="bg-nature-100 p-2 rounded-full">
                    <Clock className="w-5 h-5 text-nature-600" />
                  </div>
                  <div>
                    <h3 className="font-medium">Flexible Scheduling</h3>
                    <p className="text-sm text-muted-foreground">
                      Set your own availability that works with your schedule.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="md:col-span-3">
              <Card className="border-nature-100">
                <CardContent className="p-6">
                  <h3 className="text-xl font-medium mb-6">Host Application</h3>
                  <form className="space-y-4">
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label htmlFor="first-name" className="text-sm font-medium">
                          First Name
                        </label>
                        <Input id="first-name" placeholder="Your first name" className="border-nature-200" />
                      </div>
                      
                      <div className="space-y-2">
                        <label htmlFor="last-name" className="text-sm font-medium">
                          Last Name
                        </label>
                        <Input id="last-name" placeholder="Your last name" className="border-nature-200" />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <label htmlFor="email" className="text-sm font-medium">
                        Email
                      </label>
                      <Input id="email" type="email" placeholder="your.email@example.com" className="border-nature-200" />
                    </div>
                    
                    <div className="space-y-2">
                      <label htmlFor="phone" className="text-sm font-medium">
                        Phone Number
                      </label>
                      <Input id="phone" placeholder="+91 12345 67890" className="border-nature-200" />
                    </div>
                    
                    <div className="space-y-2">
                      <label htmlFor="location" className="text-sm font-medium">
                        Location
                      </label>
                      <Input id="location" placeholder="Village, District, State" className="border-nature-200" />
                    </div>
                    
                    <div className="space-y-2">
                      <label htmlFor="experience-type" className="text-sm font-medium">
                        Experience Type
                      </label>
                      <Input id="experience-type" placeholder="e.g., Farming Workshop, Cooking Class" className="border-nature-200" />
                    </div>
                    
                    <div className="space-y-2">
                      <label htmlFor="description" className="text-sm font-medium">
                        Tell us about your experience
                      </label>
                      <Textarea 
                        id="description" 
                        placeholder="Please describe the experience you'd like to host and your background/qualifications related to it."
                        className="min-h-[100px] border-nature-200"
                      />
                    </div>
                    
                    <Button className="w-full bg-nature-600 hover:bg-nature-700 text-white">
                      Submit Application
                    </Button>
                    
                    <p className="text-xs text-muted-foreground text-center">
                      By submitting this form, you agree to our <a href="#" className="text-nature-600 hover:underline">Terms of Service</a> and <a href="#" className="text-nature-600 hover:underline">Privacy Policy</a>.
                    </p>
                  </form>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </MainLayout>
  );
}
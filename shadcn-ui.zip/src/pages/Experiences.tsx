import { MainLayout } from "@/components/layout/main-layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Clock, MapPin, Search, User, X } from "lucide-react";
import { useState } from "react";

// Mock data for experiences
const allExperiences = [
  {
    id: 1,
    name: "Organic Farming Workshop",
    location: "Multiple Locations",
    price: 1200,
    rating: 4.8,
    image: "/assets/images/farming-workshop.jpg",
    duration: "Half-day",
    host: "Local Farmers Collective",
    category: "Farming",
    groupSize: "Up to 10 people"
  },
  {
    id: 2,
    name: "Traditional Cooking Class",
    location: "Multiple Locations",
    price: 1500,
    rating: 4.7,
    image: "/assets/images/cooking-class.jpg",
    duration: "3 hours",
    host: "Village Home Chefs",
    category: "Culinary",
    groupSize: "Up to 8 people"
  },
  {
    id: 3,
    name: "Guided Nature Walks",
    location: "Multiple Locations",
    price: 800,
    rating: 4.9,
    image: "/images/Nature.jpg",
    duration: "2 hours",
    host: "Wilderness Explorers",
    category: "Nature",
    groupSize: "Up to 12 people"
  },
  {
    id: 4,
    name: "Pottery Making with Local Artisans",
    location: "Rajasthan",
    price: 1100,
    rating: 4.8,
    image: "/assets/images/pottery-class.jpg",
    duration: "3 hours",
    host: "Rural Artisans Collective",
    category: "Craft",
    groupSize: "Up to 6 people"
  },
  {
    id: 5,
    name: "Tribal Music & Dance Experience",
    location: "Madhya Pradesh",
    price: 950,
    rating: 4.9,
    image: "/assets/images/tribal-dance.jpg",
    duration: "Evening",
    host: "Indigenous Cultural Group",
    category: "Cultural",
    groupSize: "Up to 20 people"
  },
  {
    id: 6,
    name: "Sustainable Beekeeping Workshop",
    location: "Uttarakhand",
    price: 1300,
    rating: 4.7,
    image: "/assets/images/beekeeping.jpg",
    duration: "Half-day",
    host: "Mountain Honey Cooperative",
    category: "Farming",
    groupSize: "Up to 8 people"
  },
  {
    id: 7,
    name: "Herbal Medicine Walk",
    location: "Kerala",
    price: 900,
    rating: 4.8,
    image: "/assets/images/herbal-walk.jpg",
    duration: "3 hours",
    host: "Traditional Healers Network",
    category: "Nature",
    groupSize: "Up to 10 people"
  },
  {
    id: 8,
    name: "Traditional Weaving Class",
    location: "Assam",
    price: 1200,
    rating: 4.6,
    image: "/assets/images/weaving-class.jpg",
    duration: "4 hours",
    host: "Women Weavers Collective",
    category: "Craft",
    groupSize: "Up to 6 people"
  },
];

export default function ExperiencesPage() {
  const [priceRange, setPriceRange] = useState<[number, number]>([500, 2000]);
  const [searchTerm, setSearchTerm] = useState("");
  const [activeFilters, setActiveFilters] = useState<string[]>([]);

  // Filter experiences based on search term, price range and active filters
  const filteredExperiences = allExperiences.filter(exp => {
    const matchesSearch = exp.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          exp.location.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesPrice = exp.price >= priceRange[0] && exp.price <= priceRange[1];
    
    const matchesFilters = activeFilters.length === 0 || 
                           activeFilters.includes(exp.category) ||
                           activeFilters.includes(exp.duration);
    
    return matchesSearch && matchesPrice && matchesFilters;
  });

  // Add or remove a filter
  const toggleFilter = (filter: string) => {
    if (activeFilters.includes(filter)) {
      setActiveFilters(activeFilters.filter(f => f !== filter));
    } else {
      setActiveFilters([...activeFilters, filter]);
    }
  };

  // Clear all filters
  const clearFilters = () => {
    setPriceRange([500, 2000]);
    setSearchTerm("");
    setActiveFilters([]);
  };

  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="relative py-12 bg-nature-600">
        <div className="container">
          <div className="max-w-3xl text-white">
            <h1 className="text-4xl font-semibold mb-4">Immersive Rural Experiences</h1>
            <p className="text-lg text-nature-100 mb-8">
              Connect with local traditions, learn new skills, and create unforgettable memories
            </p>
          </div>
        </div>
      </section>
      
      {/* Search and Filter Section */}
      <section className="bg-white border-b border-nature-100 sticky top-16 z-30">
        <div className="container py-4">
          <div className="flex flex-wrap items-center gap-4">
            {/* Search Input */}
            <div className="flex-1 min-w-[200px]">
              <div className="flex items-center border border-nature-200 rounded-lg p-2 bg-white focus-within:ring-1 focus-within:ring-primary">
                <Search className="w-5 h-5 text-muted-foreground mr-2" />
                <Input 
                  className="border-0 focus-visible:ring-0 p-0" 
                  placeholder="Search for experiences or locations"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                {searchTerm && (
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-5 w-5 p-0 text-muted-foreground"
                    onClick={() => setSearchTerm("")}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </div>
            
            {/* Filters */}
            <div className="flex flex-wrap gap-2 items-center">
              <Select>
                <SelectTrigger className="w-[150px] border-nature-200">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="farming">Farming</SelectItem>
                  <SelectItem value="craft">Crafts</SelectItem>
                  <SelectItem value="nature">Nature</SelectItem>
                  <SelectItem value="culinary">Culinary</SelectItem>
                  <SelectItem value="cultural">Cultural</SelectItem>
                </SelectContent>
              </Select>
              
              <Select>
                <SelectTrigger className="w-[150px] border-nature-200">
                  <SelectValue placeholder="Duration" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="short">Under 2 hours</SelectItem>
                  <SelectItem value="medium">2-4 hours</SelectItem>
                  <SelectItem value="long">Half-day</SelectItem>
                  <SelectItem value="full">Full day</SelectItem>
                </SelectContent>
              </Select>
              
              <Button 
                variant="outline" 
                className="border-nature-200"
                onClick={clearFilters}
              >
                Clear Filters
              </Button>
            </div>
          </div>
          
          {/* Active filters */}
          {activeFilters.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-3">
              {activeFilters.map(filter => (
                <div 
                  key={filter}
                  className="bg-nature-100 text-nature-700 text-sm px-3 py-1 rounded-full flex items-center gap-1"
                >
                  {filter}
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-4 w-4 p-0 hover:bg-transparent"
                    onClick={() => toggleFilter(filter)}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              ))}
              
              <Button 
                variant="ghost" 
                className="text-sm text-nature-600 h-6 px-2"
                onClick={clearFilters}
              >
                Clear All
              </Button>
            </div>
          )}
        </div>
      </section>
      
      <div className="container py-8">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Sidebar with filters */}
          <div className="lg:w-1/4 space-y-6">
            <Card className="border-nature-100">
              <CardContent className="p-4">
                <h3 className="text-lg font-medium mb-4">Filters</h3>
                
                <Accordion type="multiple" className="space-y-2">
                  <AccordionItem value="price" className="border-nature-100">
                    <AccordionTrigger className="py-2 text-sm font-medium hover:no-underline">
                      Price Range
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-4 pt-2">
                        <Slider 
                          value={priceRange}
                          min={500}
                          max={2000}
                          step={100}
                          onValueChange={(value) => setPriceRange(value as [number, number])}
                          className="py-4"
                        />
                        <div className="flex justify-between text-sm">
                          <span>₹{priceRange[0]}</span>
                          <span>₹{priceRange[1]}</span>
                        </div>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                  
                  <AccordionItem value="categories" className="border-nature-100">
                    <AccordionTrigger className="py-2 text-sm font-medium hover:no-underline">
                      Categories
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-2">
                        {["Farming", "Culinary", "Nature", "Craft", "Cultural"].map((category) => (
                          <div key={category} className="flex items-center space-x-2">
                            <Checkbox 
                              id={category.toLowerCase()}
                              checked={activeFilters.includes(category)}
                              onCheckedChange={() => toggleFilter(category)}
                            />
                            <label 
                              htmlFor={category.toLowerCase()} 
                              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              {category}
                            </label>
                          </div>
                        ))}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                  
                  <AccordionItem value="duration" className="border-nature-100">
                    <AccordionTrigger className="py-2 text-sm font-medium hover:no-underline">
                      Duration
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-2">
                        {["2 hours", "3 hours", "4 hours", "Half-day", "Full day", "Evening"].map((duration) => (
                          <div key={duration} className="flex items-center space-x-2">
                            <Checkbox 
                              id={duration.toLowerCase().replace(/\s/g, '-')}
                              checked={activeFilters.includes(duration)}
                              onCheckedChange={() => toggleFilter(duration)}
                            />
                            <label 
                              htmlFor={duration.toLowerCase().replace(/\s/g, '-')} 
                              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              {duration}
                            </label>
                          </div>
                        ))}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </CardContent>
            </Card>
          </div>
          
          {/* Main content with experiences listing */}
          <div className="lg:w-3/4">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-medium">
                {filteredExperiences.length} {filteredExperiences.length === 1 ? 'experience' : 'experiences'} available
              </h2>
              <Select defaultValue="recommended">
                <SelectTrigger className="w-[180px] border-nature-200">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="recommended">Recommended</SelectItem>
                  <SelectItem value="price-low">Price: Low to High</SelectItem>
                  <SelectItem value="price-high">Price: High to Low</SelectItem>
                  <SelectItem value="rating">Rating: High to Low</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredExperiences.map((exp) => (
                <Card key={exp.id} className="border-nature-100 overflow-hidden group hover-lift">
                  <div className="aspect-[4/3] relative overflow-hidden">
                    <div className="absolute inset-0 bg-nature-800/20 group-hover:bg-nature-800/10 transition-colors z-10" />
                    <img 
                      src={exp.image || "https://placehold.co/400x300?text=Experience"} 
                      alt={exp.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    />
                    <div className="absolute top-3 left-3 flex gap-2 z-20">
                      <span className="text-xs bg-white/90 backdrop-blur-sm px-2 py-1 rounded-full text-nature-800 font-medium">
                        {exp.category}
                      </span>
                    </div>
                  </div>
                  <CardContent className="p-5">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-medium text-lg">{exp.name}</h3>
                      <div className="flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 text-amber-400">
                          <path fillRule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z" clipRule="evenodd" />
                        </svg>
                        <span className="text-sm font-medium ml-1">{exp.rating}</span>
                      </div>
                    </div>
                    <ul className="text-sm text-muted-foreground mb-3 space-y-1">
                      <li className="flex items-center gap-2">
                        <Clock className="w-3.5 h-3.5" />
                        {exp.duration}
                      </li>
                      <li className="flex items-center gap-2">
                        <MapPin className="w-3.5 h-3.5" />
                        {exp.location}
                      </li>
                      <li className="flex items-center gap-2">
                        <User className="w-3.5 h-3.5" />
                        Hosted by: {exp.host}
                      </li>
                    </ul>
                    <div className="flex justify-between items-center mt-4">
                      <div>
                        <span className="font-semibold">₹{exp.price}</span>
                        <span className="text-sm text-muted-foreground">/person</span>
                      </div>
                      <Button 
                        size="sm" 
                        className="bg-nature-600 hover:bg-nature-700 text-white"
                        onClick={() => window.location.href = "/experiences/exp-123"}
                      >
                        Book Now
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            
            {filteredExperiences.length === 0 && (
              <div className="text-center py-12">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-nature-100 mb-4">
                  <Search className="w-8 h-8 text-nature-600" />
                </div>
                <h3 className="text-xl font-medium mb-2">No experiences found</h3>
                <p className="text-muted-foreground mb-6">
                  We couldn't find any experiences matching your current filters.
                </p>
                <Button 
                  variant="outline" 
                  className="border-nature-200"
                  onClick={clearFilters}
                >
                  Clear All Filters
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Become Host Section */}
      <section className="bg-nature-600 py-16">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-10 items-center">
            <div className="relative h-[300px] md:h-[400px]">
              <div className="absolute inset-0 rounded-lg overflow-hidden">
                <img 
                  src="/assets/images/host-experience.jpg" 
                  alt="Host leading an experience"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
            
            <div className="space-y-6 text-white">
              <h2 className="text-3xl md:text-4xl font-medium">Share Your Rural Skills & Knowledge</h2>
              <p className="text-nature-100 text-lg">
                Are you a farmer, artisan, or knowledge keeper from a rural community? Partner with KrishiSafar to share your skills and earn additional income while preserving traditional knowledge.
              </p>
              <Button asChild className="bg-white text-nature-700 hover:bg-nature-100">
                <a href="/hosts">Become a Host</a>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </MainLayout>
  );
}
import { useState } from "react";
import { MainLayout } from "@/components/layout/main-layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";
import { CalendarIcon, CheckCircle, ChevronLeft, Home, MapPin, Star, Users, Utensils, Wifi } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { format } from "date-fns";

export default function StayDetailPage() {
  const [date, setDate] = useState<Date | undefined>(undefined);
  const [guests, setGuests] = useState(1);
  const navigate = useNavigate();

  // In a real app, this would be fetched based on the URL param
  const stay = {
    id: "farm-123",
    name: "Peaceful Organic Farm Cottage",
    location: "Coorg, Karnataka",
    price: 4500,
    rating: 4.9,
    reviews: 124,
    images: [
      "/assets/images/stays/farm-cottage-1.jpg",
      "/assets/images/stays/farm-cottage-2.jpg",
      "/assets/images/stays/farm-cottage-3.jpg",
    ],
    host: {
      name: "Ravi Kumar",
      image: "/assets/images/hosts/ravi.jpg",
      isSuperhost: true,
    },
    description: 
      "Experience the tranquility of rural life at our organic farm cottage. Nestled amidst coffee plantations and spice gardens, this eco-friendly retreat offers panoramic views of the Western Ghats. Wake up to bird songs, help with farm activities, and enjoy farm-to-table meals prepared with ingredients harvested from our garden.",
    amenities: [
      { icon: <Home size={16} />, name: "Private cottage" },
      { icon: <Wifi size={16} />, name: "Fast WiFi" },
      { icon: <Utensils size={16} />, name: "Farm-to-table meals" },
      { icon: <Users size={16} />, name: "Up to 4 guests" },
    ],
    features: [
      "Organic farm stay experience",
      "Farm walk and activities",
      "Traditional home-cooked meals",
      "Coffee plantation tour",
      "Bird watching",
      "Spice garden visit",
    ]
  };

  const handleBookNow = () => {
    // In a real app, this would navigate to a checkout page
    alert("Booking process would start here!");
  };

  return (
    <MainLayout>
      {/* Navigation Back */}
      <div className="container py-4">
        <Button 
          variant="ghost" 
          className="flex items-center text-muted-foreground mb-2"
          onClick={() => navigate("/stays")}
        >
          <ChevronLeft className="h-4 w-4 mr-1" />
          Back to Stays
        </Button>
      </div>

      {/* Image Gallery */}
      <section className="container pb-8">
        <div className="grid md:grid-cols-2 gap-4">
          <div className="aspect-[4/3] relative rounded-lg overflow-hidden">
            <div className="absolute inset-0 bg-nature-100 flex items-center justify-center">
              <p className="text-nature-600 font-medium">Main Image</p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="aspect-[4/3] relative rounded-lg overflow-hidden">
              <div className="absolute inset-0 bg-nature-100 flex items-center justify-center">
                <p className="text-nature-600 font-medium">Image 2</p>
              </div>
            </div>
            <div className="aspect-[4/3] relative rounded-lg overflow-hidden">
              <div className="absolute inset-0 bg-nature-100 flex items-center justify-center">
                <p className="text-nature-600 font-medium">Image 3</p>
              </div>
            </div>
            <div className="aspect-[4/3] relative rounded-lg overflow-hidden">
              <div className="absolute inset-0 bg-nature-100 flex items-center justify-center">
                <p className="text-nature-600 font-medium">Image 4</p>
              </div>
            </div>
            <div className="aspect-[4/3] relative rounded-lg overflow-hidden">
              <div className="absolute inset-0 bg-nature-100 flex items-center justify-center">
                <p className="text-nature-600 font-medium">Image 5</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stay Details */}
      <section className="container pb-16">
        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h1 className="text-3xl font-semibold mb-2">{stay.name}</h1>
                <div className="flex items-center text-muted-foreground">
                  <MapPin className="h-4 w-4 mr-1" />
                  <span>{stay.location}</span>
                </div>
              </div>
              <div className="flex items-center">
                <Star className="h-5 w-5 text-yellow-500 fill-yellow-500 mr-1" />
                <span className="font-medium">{stay.rating}</span>
                <span className="text-muted-foreground ml-1">({stay.reviews} reviews)</span>
              </div>
            </div>

            <div className="flex items-center mb-6">
              <div className="h-10 w-10 rounded-full bg-nature-100 mr-3 flex items-center justify-center">
                <p className="text-nature-600 font-medium">H</p>
              </div>
              <div>
                <p className="font-medium">Hosted by {stay.host.name}</p>
                {stay.host.isSuperhost && (
                  <div className="flex items-center text-sm text-muted-foreground">
                    <CheckCircle className="h-3 w-3 mr-1 text-green-500" />
                    <span>Superhost</span>
                  </div>
                )}
              </div>
            </div>

            <hr className="border-nature-100 my-6" />

            <div className="mb-8">
              <h2 className="text-xl font-medium mb-4">About This Farm Stay</h2>
              <p className="text-muted-foreground">{stay.description}</p>
            </div>

            <div className="mb-8">
              <h2 className="text-xl font-medium mb-4">Amenities</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {stay.amenities.map((amenity, index) => (
                  <div key={index} className="flex items-center">
                    <div className="h-8 w-8 rounded-full bg-nature-100 flex items-center justify-center mr-3">
                      {amenity.icon}
                    </div>
                    <span>{amenity.name}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="mb-8">
              <h2 className="text-xl font-medium mb-4">Farm Stay Features</h2>
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {stay.features.map((feature, index) => (
                  <li key={index} className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-green-500 mr-2 flex-shrink-0" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h2 className="text-xl font-medium mb-4">Location</h2>
              <div className="aspect-[16/9] bg-nature-100 rounded-lg overflow-hidden relative">
                <div className="absolute inset-0 flex items-center justify-center">
                  <p className="text-nature-600 font-medium">Map will be displayed here</p>
                </div>
              </div>
            </div>
          </div>

          <div>
            <Card className="sticky top-24 border-nature-100 shadow-natural">
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-4">
                  <div>
                    <span className="text-2xl font-semibold">₹{stay.price}</span>
                    <span className="text-muted-foreground"> / night</span>
                  </div>
                  <div className="flex items-center">
                    <Star className="h-4 w-4 text-yellow-500 fill-yellow-500 mr-1" />
                    <span className="font-medium">{stay.rating}</span>
                  </div>
                </div>

                <Tabs defaultValue="booking" className="mb-6">
                  <TabsList className="grid grid-cols-2 mb-4">
                    <TabsTrigger value="booking">Booking</TabsTrigger>
                    <TabsTrigger value="enquiry">Enquiry</TabsTrigger>
                  </TabsList>
                  <TabsContent value="booking" className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Dates</label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className="w-full justify-start text-left font-normal border-nature-200"
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {date ? format(date, "PPP") : <span>Pick a date</span>}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={date}
                            onSelect={setDate}
                            initialFocus
                            className="rounded-md border"
                          />
                        </PopoverContent>
                      </Popover>
                    </div>

                    <div className="space-y-2">
                      <label htmlFor="guests" className="text-sm font-medium">
                        Guests
                      </label>
                      <div className="flex items-center">
                        <Button 
                          variant="outline" 
                          size="icon" 
                          className="border-nature-200"
                          onClick={() => setGuests(Math.max(1, guests - 1))}
                        >
                          -
                        </Button>
                        <div className="w-12 text-center font-medium">{guests}</div>
                        <Button 
                          variant="outline" 
                          size="icon" 
                          className="border-nature-200"
                          onClick={() => setGuests(Math.min(10, guests + 1))}
                        >
                          +
                        </Button>
                      </div>
                    </div>

                    <Button 
                      className="w-full bg-nature-600 hover:bg-nature-700 text-white"
                      onClick={handleBookNow}
                    >
                      Book Now
                    </Button>

                    <div className="space-y-4 pt-4 border-t border-nature-100">
                      <div className="flex justify-between">
                        <span>₹{stay.price} × 1 night</span>
                        <span>₹{stay.price}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Service fee</span>
                        <span>₹{Math.round(stay.price * 0.1)}</span>
                      </div>
                      <div className="flex justify-between font-medium pt-4 border-t border-nature-100">
                        <span>Total</span>
                        <span>₹{stay.price + Math.round(stay.price * 0.1)}</span>
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="enquiry" className="space-y-4">
                    <Input placeholder="Your Name" className="border-nature-200" />
                    <Input placeholder="Your Email" type="email" className="border-nature-200" />
                    <Input placeholder="Your Phone" type="tel" className="border-nature-200" />
                    <Input placeholder="Your Message" className="border-nature-200" />
                    <Button className="w-full bg-nature-600 hover:bg-nature-700 text-white">
                      Send Enquiry
                    </Button>
                  </TabsContent>
                </Tabs>

                <div className="text-center text-sm text-muted-foreground">
                  <p>No charge until you book</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* More Stays */}
      <section className="bg-nature-50 py-16 border-t border-nature-100">
        <div className="container">
          <h2 className="text-2xl font-semibold mb-8">More Stays You Might Like</h2>
          <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((item) => (
              <Link to="/stays/farm-123" key={item}>
                <div className="group rounded-lg overflow-hidden transition-all duration-300 hover:shadow-md">
                  <div className="aspect-[4/3] bg-nature-100 relative">
                    <div className="absolute inset-0 flex items-center justify-center">
                      <p className="text-nature-600 font-medium">Image</p>
                    </div>
                    <Badge className="absolute top-2 right-2 bg-white text-nature-800 hover:bg-white">
                      Farm Stay
                    </Badge>
                  </div>
                  <div className="p-4 bg-white">
                    <div className="flex justify-between">
                      <h3 className="font-medium group-hover:text-nature-700">Hillside Farm Cottage</h3>
                      <div className="flex items-center">
                        <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                        <span className="text-sm ml-1">4.8</span>
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">Sakleshpur, Karnataka</p>
                    <p className="font-medium">₹3,500 <span className="text-sm font-normal text-muted-foreground">/ night</span></p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </MainLayout>
  );
}
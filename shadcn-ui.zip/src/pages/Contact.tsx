import { MainLayout } from "@/components/layout/main-layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Mail, MapPin, MessageSquare, Phone } from "lucide-react";

export default function ContactPage() {
  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="relative py-20 bg-nature-50 border-b border-nature-100">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-semibold mb-6">Contact Us</h1>
            <p className="text-xl text-muted-foreground mb-8">
              Have questions or feedback? We'd love to hear from you.
            </p>
          </div>
        </div>
      </section>
      
      {/* Contact Form Section */}
      <section className="py-16">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 items-start">
            <div>
              <h2 className="text-3xl font-medium mb-6">Get in Touch</h2>
              <p className="text-muted-foreground mb-8">
                Whether you have questions about booking a stay, want to learn more about hosting, or just want to say hello, we're here to help.
              </p>
              
              <div className="space-y-6">
                <div className="flex gap-4 items-start">
                  <div className="bg-nature-100 p-3 rounded-full">
                    <MapPin className="w-5 h-5 text-nature-600" />
                  </div>
                  <div>
                    <h3 className="font-medium text-lg mb-1">Our Office</h3>
                    <p className="text-muted-foreground">
                      123 Green Way, Eco Park<br />
                      Bangalore, Karnataka 560001<br />
                      India
                    </p>
                  </div>
                </div>
                
                <div className="flex gap-4 items-start">
                  <div className="bg-nature-100 p-3 rounded-full">
                    <Mail className="w-5 h-5 text-nature-600" />
                  </div>
                  <div>
                    <h3 className="font-medium text-lg mb-1">Email Us</h3>
                    <p className="text-muted-foreground">
                      General Inquiries: info@krishisafar.com<br />
                      Support: support@krishisafar.com<br />
                      Partnerships: partners@krishisafar.com
                    </p>
                  </div>
                </div>
                
                <div className="flex gap-4 items-start">
                  <div className="bg-nature-100 p-3 rounded-full">
                    <Phone className="w-5 h-5 text-nature-600" />
                  </div>
                  <div>
                    <h3 className="font-medium text-lg mb-1">Call Us</h3>
                    <p className="text-muted-foreground">
                      Phone: +91 80 2345 6789<br />
                      Toll-Free: 1800 123 4567<br />
                      Hours: Mon-Fri, 9am-6pm IST
                    </p>
                  </div>
                </div>
                
                <div className="flex gap-4 items-start">
                  <div className="bg-nature-100 p-3 rounded-full">
                    <MessageSquare className="w-5 h-5 text-nature-600" />
                  </div>
                  <div>
                    <h3 className="font-medium text-lg mb-1">Social Media</h3>
                    <div className="flex gap-4 mt-2">
                      <a href="#" className="text-muted-foreground hover:text-nature-600">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path></svg>
                      </a>
                      <a href="#" className="text-muted-foreground hover:text-nature-600">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line></svg>
                      </a>
                      <a href="#" className="text-muted-foreground hover:text-nature-600">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path></svg>
                      </a>
                      <a href="#" className="text-muted-foreground hover:text-nature-600">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path><rect x="2" y="9" width="4" height="12"></rect><circle cx="4" cy="4" r="2"></circle></svg>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <Card className="border-nature-100 shadow-natural">
              <CardContent className="p-6">
                <h3 className="text-xl font-medium mb-6">Send Us a Message</h3>
                <form className="space-y-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label htmlFor="first-name" className="text-sm font-medium">
                        First Name
                      </label>
                      <Input id="first-name" placeholder="Your first name" className="border-nature-200" />
                    </div>
                    
                    <div className="space-y-2">
                      <label htmlFor="last-name" className="text-sm font-medium">
                        Last Name
                      </label>
                      <Input id="last-name" placeholder="Your last name" className="border-nature-200" />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="email" className="text-sm font-medium">
                      Email
                    </label>
                    <Input id="email" type="email" placeholder="your.email@example.com" className="border-nature-200" />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="subject" className="text-sm font-medium">
                      Subject
                    </label>
                    <Input id="subject" placeholder="How can we help you?" className="border-nature-200" />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="message" className="text-sm font-medium">
                      Message
                    </label>
                    <Textarea 
                      id="message" 
                      placeholder="Please provide details about your inquiry..."
                      className="min-h-[150px] border-nature-200"
                    />
                  </div>
                  
                  <Button className="w-full bg-nature-600 hover:bg-nature-700 text-white">
                    Send Message
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
      
      {/* Map Section */}
      <section className="py-12">
        <div className="container">
          <div className="aspect-[21/9] max-h-[400px] bg-nature-100 rounded-lg overflow-hidden relative">
            <div className="absolute inset-0 flex items-center justify-center">
              <p className="text-nature-600 font-medium">Map will be displayed here</p>
            </div>
          </div>
        </div>
      </section>
      
      {/* FAQ Section */}
      <section className="py-16 bg-nature-50 border-y border-nature-100">
        <div className="container">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-3xl font-medium mb-4">Frequently Asked Questions</h2>
            <p className="text-muted-foreground">
              Quick answers to common questions.
            </p>
          </div>
          
          <div className="max-w-3xl mx-auto grid md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-medium mb-2">How do I book a stay?</h3>
                <p className="text-muted-foreground">
                  You can browse available stays on our platform and book directly through our website. Payment is processed securely online.
                </p>
              </div>
              
              <div>
                <h3 className="text-lg font-medium mb-2">What is your cancellation policy?</h3>
                <p className="text-muted-foreground">
                  Cancellation policies vary by property. You can view the specific policy for each stay before booking.
                </p>
              </div>
              
              <div>
                <h3 className="text-lg font-medium mb-2">How do I become a host?</h3>
                <p className="text-muted-foreground">
                  Visit our "Become a Host" page to learn about the process and fill out an application form.
                </p>
              </div>
            </div>
            
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-medium mb-2">Are the farms organic?</h3>
                <p className="text-muted-foreground">
                  Many of our partner farms practice organic or traditional farming methods. Each listing specifies their farming practices.
                </p>
              </div>
              
              <div>
                <h3 className="text-lg font-medium mb-2">Do you offer group bookings?</h3>
                <p className="text-muted-foreground">
                  Yes, we accommodate group bookings. Please contact us directly for special arrangements for larger groups.
                </p>
              </div>
              
              <div>
                <h3 className="text-lg font-medium mb-2">How can I partner with KrishiSafar?</h3>
                <p className="text-muted-foreground">
                  We're always open to partnerships that align with our mission. Please email partners@krishisafar.com with your proposal.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </MainLayout>
  );
}
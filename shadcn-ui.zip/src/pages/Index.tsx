import { MainLayout } from "@/components/layout/main-layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { CalendarIcon, Leaf, Map, MountainSnow, Search, Tent, Tractor, Users } from "lucide-react";
import { Link } from "react-router-dom";

// Mock data for featured stays
const featuredStays = [
  {
    id: 1,
    name: "Sunset Valley Farm Retreat",
    location: "Himachal Pradesh",
    price: 2500,
    rating: 4.9,
    image: "/assets/images/farm-retreat.jpg",
    tags: ["Farm Stay", "Mountains"]
  },
  {
    id: 2,
    name: "Green Meadows Eco Lodge",
    location: "Kerala",
    price: 3200,
    rating: 4.8,
    image: "/assets/images/eco-lodge.jpg",
    tags: ["Eco-friendly", "Waterfront"]
  },
  {
    id: 3,
    name: "Organic Orchard Homestay",
    location: "Karnataka",
    price: 1800,
    rating: 4.7,
    image: "/assets/images/orchard-homestay.jpg",
    tags: ["Organic Farm", "Family-friendly"]
  },
  {
    id: 4,
    name: "Mountain View Cottage",
    location: "Uttarakhand",
    price: 2800,
    rating: 4.9,
    image: "/assets/images/mountain-cottage.jpg",
    tags: ["Mountain View", "Hiking"]
  }
];

// Mock data for featured experiences
const featuredExperiences = [
  {
    id: 1,
    name: "Organic Farming Workshop",
    location: "Multiple Locations",
    price: 1200,
    rating: 4.8,
    image: "/assets/images/farming-workshop.jpg",
    duration: "Half-day"
  },
  {
    id: 2,
    name: "Traditional Cooking Class",
    location: "Multiple Locations",
    price: 1500,
    rating: 4.7,
    image: "/assets/images/cooking-class.jpg",
    duration: "3 hours"
  },
  {
    id: 3,
    name: "Guided Nature Walks",
    location: "Multiple Locations",
    price: 800,
    rating: 4.9,
    image: "/images/Nature.jpg",
    duration: "2 hours"
  }
];

export default function HomePage() {
  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="relative h-[85vh] min-h-[600px] w-full bg-nature-100 overflow-hidden">
        <div className="absolute inset-0 bg-[url('/images/Nature.jpg')] bg-cover bg-center">
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-background/90" />
        </div>
        
        <div className="container relative h-full flex flex-col justify-center items-start">
          <div className="max-w-2xl space-y-6 animate-in fade-in slide-up duration-700">
            <h1 className="text-5xl md:text-6xl font-bold tracking-tight text-white drop-shadow-md">
              Connect with <span className="text-gradient-nature">Nature</span>, One Stay at a Time
            </h1>
            <p className="text-lg md:text-xl text-white/90 max-w-xl">
              Discover authentic farm stays, eco-retreats, and immersive nature experiences across India.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button className="bg-nature-600 hover:bg-nature-700 text-white font-medium px-6 py-2 text-lg">
                <Link to="/stays">Explore Stays</Link>
              </Button>
              <Button variant="outline" className="bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20 font-medium px-6 py-2 text-lg">
                <Link to="/experiences">Browse Experiences</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
      
      {/* Search Bar */}
      <section className="container -mt-16 relative z-10">
        <Card className="shadow-natural bg-background border-nature-100">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="flex items-center border border-nature-200 rounded-lg p-3 bg-white focus-within:ring-1 focus-within:ring-primary">
                  <Map className="w-5 h-5 text-muted-foreground mr-2" />
                  <Input 
                    className="border-0 focus-visible:ring-0 p-0" 
                    placeholder="Where to? (Destination, City)"
                  />
                </div>
              </div>
              <div className="flex-1">
                <div className="flex items-center border border-nature-200 rounded-lg p-3 bg-white focus-within:ring-1 focus-within:ring-primary">
                  <CalendarIcon className="w-5 h-5 text-muted-foreground mr-2" />
                  <Input 
                    className="border-0 focus-visible:ring-0 p-0" 
                    placeholder="Check in - Check out"
                  />
                </div>
              </div>
              <div className="md:w-auto">
                <div className="flex items-center border border-nature-200 rounded-lg p-3 bg-white focus-within:ring-1 focus-within:ring-primary">
                  <Users className="w-5 h-5 text-muted-foreground mr-2" />
                  <Input 
                    className="border-0 focus-visible:ring-0 p-0 w-full md:w-[100px]" 
                    placeholder="Guests"
                  />
                </div>
              </div>
              <Button className="bg-nature-600 hover:bg-nature-700 text-white flex gap-2 h-[50px]">
                <Search className="w-5 h-5" />
                <span>Search</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      </section>
      
      {/* Categories */}
      <section className="container py-16">
        <h2 className="text-3xl font-medium mb-8">Explore by Category</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          <Card className="border-nature-100 group hover-lift cursor-pointer overflow-hidden">
            <CardContent className="p-6 flex flex-col items-center gap-3">
              <div className="bg-nature-100 p-3 rounded-full group-hover:bg-nature-200 transition-colors">
                <Tractor className="w-8 h-8 text-nature-700" />
              </div>
              <span className="text-lg font-medium">Farm Stays</span>
            </CardContent>
          </Card>
          
          <Card className="border-nature-100 group hover-lift cursor-pointer overflow-hidden">
            <CardContent className="p-6 flex flex-col items-center gap-3">
              <div className="bg-nature-100 p-3 rounded-full group-hover:bg-nature-200 transition-colors">
                <Leaf className="w-8 h-8 text-nature-700" />
              </div>
              <span className="text-lg font-medium">Eco Retreats</span>
            </CardContent>
          </Card>
          
          <Card className="border-nature-100 group hover-lift cursor-pointer overflow-hidden">
            <CardContent className="p-6 flex flex-col items-center gap-3">
              <div className="bg-nature-100 p-3 rounded-full group-hover:bg-nature-200 transition-colors">
                <MountainSnow className="w-8 h-8 text-nature-700" />
              </div>
              <span className="text-lg font-medium">Hill Stations</span>
            </CardContent>
          </Card>
          
          <Card className="border-nature-100 group hover-lift cursor-pointer overflow-hidden">
            <CardContent className="p-6 flex flex-col items-center gap-3">
              <div className="bg-nature-100 p-3 rounded-full group-hover:bg-nature-200 transition-colors">
                <Tent className="w-8 h-8 text-nature-700" />
              </div>
              <span className="text-lg font-medium">Camping</span>
            </CardContent>
          </Card>
        </div>
      </section>
      
      {/* Featured Stays */}
      <section className="container py-12">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-medium">Featured Stays</h2>
          <Button variant="outline" className="border-nature-200 hover:bg-nature-50 text-nature-700">
            <Link to="/stays">View All</Link>
          </Button>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredStays.map((stay) => (
            <Card key={stay.id} className="border-nature-100 overflow-hidden group hover-lift">
              <div className="aspect-[4/3] relative overflow-hidden">
                <div className="absolute inset-0 bg-nature-800/20 group-hover:bg-nature-800/10 transition-colors z-10" />
                <img 
                  src={stay.image || "https://placehold.co/400x300?text=KrishiSafar"} 
                  alt={stay.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute top-3 left-3 flex gap-2 z-20">
                  {stay.tags.map((tag, idx) => (
                    <span key={idx} className="text-xs bg-white/90 backdrop-blur-sm px-2 py-1 rounded-full text-nature-800 font-medium">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
              <CardContent className="p-5">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-medium text-lg">{stay.name}</h3>
                  <div className="flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 text-amber-400">
                      <path fillRule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z" clipRule="evenodd" />
                    </svg>
                    <span className="text-sm font-medium ml-1">{stay.rating}</span>
                  </div>
                </div>
                <div className="flex justify-between items-end">
                  <div>
                    <p className="text-sm text-muted-foreground flex items-center">
                      <Map className="w-4 h-4 mr-1" strokeWidth={1.5} />
                      {stay.location}
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="font-semibold">₹{stay.price}</span>
                    <span className="text-sm text-muted-foreground">/night</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
      
      {/* About Section */}
      <section className="bg-nature-50 py-16 border-y border-nature-100">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-10 items-center">
            <div className="space-y-6">
              <div className="inline-block rounded-lg bg-nature-100 px-3 py-1 text-sm text-nature-700 font-medium mb-2">
                Our Mission
              </div>
              <h2 className="text-3xl md:text-4xl font-medium leading-tight">Connecting Urban Youth with Authentic Rural Experiences</h2>
              <p className="text-lg text-muted-foreground">
                At KrishiSafar, we bridge the gap between urban youth and rural India, facilitating meaningful exchanges that benefit both communities while promoting sustainable tourism and agriculture.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 pt-2">
                <Button className="bg-nature-600 hover:bg-nature-700 text-white">
                  <Link to="/about">Read Our Story</Link>
                </Button>
                <Button variant="outline" className="border-nature-600 text-nature-700 hover:bg-nature-50">
                  <Link to="/impact">Our Impact</Link>
                </Button>
              </div>
            </div>
            
            <div className="relative h-[400px]">
              <div className="absolute top-0 right-0 w-4/5 h-4/5 rounded-lg overflow-hidden shadow-natural animate-in zoom-in">
                <img 
                  src="/assets/images/about-1.jpg" 
                  alt="Rural farm experience"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute bottom-0 left-0 w-3/5 h-3/5 rounded-lg overflow-hidden shadow-natural animate-in zoom-in delay-300">
                <img 
                  src="/assets/images/about-2.jpg" 
                  alt="Urban youth participating in farming"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
          
          {/* Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8 mt-16">
            <div className="text-center">
              <p className="text-4xl font-semibold text-nature-700">500+</p>
              <p className="text-muted-foreground mt-1">Curated Stays</p>
            </div>
            <div className="text-center">
              <p className="text-4xl font-semibold text-nature-700">20+</p>
              <p className="text-muted-foreground mt-1">States Covered</p>
            </div>
            <div className="text-center">
              <p className="text-4xl font-semibold text-nature-700">10,000+</p>
              <p className="text-muted-foreground mt-1">Happy Guests</p>
            </div>
            <div className="text-center">
              <p className="text-4xl font-semibold text-nature-700">150+</p>
              <p className="text-muted-foreground mt-1">Rural Communities Supported</p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Experiences Section */}
      <section className="container py-16">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-medium">Unique Experiences</h2>
          <Button variant="outline" className="border-nature-200 hover:bg-nature-50 text-nature-700">
            <Link to="/experiences">View All</Link>
          </Button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {featuredExperiences.map((exp) => (
            <Card key={exp.id} className="border-nature-100 overflow-hidden group hover-lift">
              <div className="aspect-video relative overflow-hidden">
                <div className="absolute inset-0 bg-nature-800/20 group-hover:bg-nature-800/10 transition-colors z-10" />
                <img 
                  src={exp.image || "https://placehold.co/600x400?text=Experience"} 
                  alt={exp.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute top-3 left-3 flex gap-2 z-20">
                  <span className="text-xs bg-white/90 backdrop-blur-sm px-2 py-1 rounded-full text-nature-800 font-medium">
                    {exp.duration}
                  </span>
                </div>
              </div>
              <CardContent className="p-5">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-medium text-lg">{exp.name}</h3>
                  <div className="flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 text-amber-400">
                      <path fillRule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z" clipRule="evenodd" />
                    </svg>
                    <span className="text-sm font-medium ml-1">{exp.rating}</span>
                  </div>
                </div>
                <div className="flex justify-between items-end">
                  <div>
                    <p className="text-sm text-muted-foreground flex items-center">
                      <Map className="w-4 h-4 mr-1" strokeWidth={1.5} />
                      {exp.location}
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="font-semibold">₹{exp.price}</span>
                    <span className="text-sm text-muted-foreground">/person</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
      
      {/* Newsletter */}
      <section className="bg-nature-600 py-16 border-y border-nature-700">
        <div className="container">
          <div className="max-w-2xl mx-auto text-center">
            <h2 className="text-3xl font-medium text-white mb-4">Stay Connected with Nature</h2>
            <p className="text-nature-100 mb-8">
              Subscribe to our newsletter for curated travel guides, seasonal offers, and farming insights.
            </p>
            <div className="flex flex-col sm:flex-row gap-3">
              <Input 
                className="bg-white/10 border-nature-500 text-white placeholder:text-nature-200 h-12"
                placeholder="Your email address" 
              />
              <Button className="bg-white text-nature-700 hover:bg-nature-100 h-12">
                Subscribe
              </Button>
            </div>
          </div>
        </div>
      </section>
    </MainLayout>
  );
}
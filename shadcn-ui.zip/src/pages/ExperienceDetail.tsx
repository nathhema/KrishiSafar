import { useState } from "react";
import { MainLayout } from "@/components/layout/main-layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";
import { CalendarIcon, ChevronLeft, Clock, MapPin, Star, Users } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { format } from "date-fns";

export default function ExperienceDetailPage() {
  const [date, setDate] = useState<Date | undefined>(undefined);
  const [guests, setGuests] = useState(1);
  const navigate = useNavigate();

  // In a real app, this would be fetched based on the URL param
  const experience = {
    id: "exp-123",
    name: "Traditional Spice Farm Tour & Cooking Workshop",
    location: "Wayanad, Kerala",
    price: 2500,
    rating: 4.8,
    reviews: 96,
    duration: "4 hours",
    host: {
      name: "Meena Thomas",
      expertise: "Spice Farmer & Culinary Expert",
    },
    description: 
      "Immerse yourself in the aromatic world of Indian spices in this hands-on experience. Begin with a guided walk through our organic spice garden, learning about the cultivation and uses of cardamom, pepper, cinnamon, and more. Then, join a traditional cooking workshop where you'll learn to blend these spices in authentic Kerala recipes. The experience concludes with enjoying the meal you've prepared, overlooking the lush plantation.",
    highlights: [
      "Guided tour of a working spice plantation",
      "Learn to identify and harvest fresh spices",
      "Traditional Kerala cooking workshop",
      "Enjoy a homemade meal with your freshly prepared dishes",
      "Take home recipe cards and a spice sample pack",
    ],
    includes: [
      "Expert guide and chef",
      "All cooking ingredients and equipment",
      "Full meal",
      "Recipe cards",
      "Spice sample pack to take home",
    ],
    schedule: [
      { time: "10:00 AM", activity: "Welcome drink and introduction" },
      { time: "10:30 AM", activity: "Guided spice garden tour" },
      { time: "11:30 AM", activity: "Spice harvesting and processing demonstration" },
      { time: "12:30 PM", activity: "Traditional cooking workshop" },
      { time: "1:30 PM", activity: "Lunch with freshly prepared dishes" },
    ]
  };

  const handleBookNow = () => {
    // In a real app, this would navigate to a checkout page
    alert("Booking process would start here!");
  };

  return (
    <MainLayout>
      {/* Navigation Back */}
      <div className="container py-4">
        <Button 
          variant="ghost" 
          className="flex items-center text-muted-foreground mb-2"
          onClick={() => navigate("/experiences")}
        >
          <ChevronLeft className="h-4 w-4 mr-1" />
          Back to Experiences
        </Button>
      </div>

      {/* Image Gallery */}
      <section className="container pb-8">
        <div className="grid md:grid-cols-2 gap-4">
          <div className="aspect-[4/3] relative rounded-lg overflow-hidden">
            <div className="absolute inset-0 bg-nature-100 flex items-center justify-center">
              <p className="text-nature-600 font-medium">Main Image</p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="aspect-[4/3] relative rounded-lg overflow-hidden">
              <div className="absolute inset-0 bg-nature-100 flex items-center justify-center">
                <p className="text-nature-600 font-medium">Image 2</p>
              </div>
            </div>
            <div className="aspect-[4/3] relative rounded-lg overflow-hidden">
              <div className="absolute inset-0 bg-nature-100 flex items-center justify-center">
                <p className="text-nature-600 font-medium">Image 3</p>
              </div>
            </div>
            <div className="aspect-[4/3] relative rounded-lg overflow-hidden">
              <div className="absolute inset-0 bg-nature-100 flex items-center justify-center">
                <p className="text-nature-600 font-medium">Image 4</p>
              </div>
            </div>
            <div className="aspect-[4/3] relative rounded-lg overflow-hidden">
              <div className="absolute inset-0 bg-nature-100 flex items-center justify-center">
                <p className="text-nature-600 font-medium">Image 5</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Experience Details */}
      <section className="container pb-16">
        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h1 className="text-3xl font-semibold mb-2">{experience.name}</h1>
                <div className="flex items-center gap-4">
                  <div className="flex items-center text-muted-foreground">
                    <MapPin className="h-4 w-4 mr-1" />
                    <span>{experience.location}</span>
                  </div>
                  <div className="flex items-center text-muted-foreground">
                    <Clock className="h-4 w-4 mr-1" />
                    <span>{experience.duration}</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center">
                <Star className="h-5 w-5 text-yellow-500 fill-yellow-500 mr-1" />
                <span className="font-medium">{experience.rating}</span>
                <span className="text-muted-foreground ml-1">({experience.reviews} reviews)</span>
              </div>
            </div>

            <div className="flex items-center mb-6">
              <div className="h-10 w-10 rounded-full bg-nature-100 mr-3 flex items-center justify-center">
                <p className="text-nature-600 font-medium">M</p>
              </div>
              <div>
                <p className="font-medium">Hosted by {experience.host.name}</p>
                <p className="text-sm text-muted-foreground">{experience.host.expertise}</p>
              </div>
            </div>

            <hr className="border-nature-100 my-6" />

            <div className="mb-8">
              <h2 className="text-xl font-medium mb-4">About This Experience</h2>
              <p className="text-muted-foreground">{experience.description}</p>
            </div>

            <div className="mb-8">
              <h2 className="text-xl font-medium mb-4">Experience Highlights</h2>
              <ul className="space-y-2">
                {experience.highlights.map((highlight, index) => (
                  <li key={index} className="flex items-start">
                    <span className="h-6 w-6 rounded-full bg-nature-100 text-nature-600 flex items-center justify-center mr-3 flex-shrink-0 font-medium text-sm">
                      {index + 1}
                    </span>
                    <span>{highlight}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="mb-8">
              <h2 className="text-xl font-medium mb-4">What's Included</h2>
              <ul className="space-y-2">
                {experience.includes.map((item, index) => (
                  <li key={index} className="flex items-center">
                    <span className="h-2 w-2 rounded-full bg-nature-600 mr-3 flex-shrink-0"></span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="mb-8">
              <h2 className="text-xl font-medium mb-4">Experience Schedule</h2>
              <div className="space-y-4">
                {experience.schedule.map((item, index) => (
                  <div key={index} className="flex items-start">
                    <div className="w-20 flex-shrink-0 font-medium">{item.time}</div>
                    <div className="bg-nature-50 border border-nature-100 p-3 rounded-md flex-grow">
                      {item.activity}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h2 className="text-xl font-medium mb-4">Location</h2>
              <div className="aspect-[16/9] bg-nature-100 rounded-lg overflow-hidden relative">
                <div className="absolute inset-0 flex items-center justify-center">
                  <p className="text-nature-600 font-medium">Map will be displayed here</p>
                </div>
              </div>
            </div>
          </div>

          <div>
            <Card className="sticky top-24 border-nature-100 shadow-natural">
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-4">
                  <div>
                    <span className="text-2xl font-semibold">₹{experience.price}</span>
                    <span className="text-muted-foreground"> / person</span>
                  </div>
                  <div className="flex items-center">
                    <Star className="h-4 w-4 text-yellow-500 fill-yellow-500 mr-1" />
                    <span className="font-medium">{experience.rating}</span>
                  </div>
                </div>

                <Tabs defaultValue="booking" className="mb-6">
                  <TabsList className="grid grid-cols-2 mb-4">
                    <TabsTrigger value="booking">Booking</TabsTrigger>
                    <TabsTrigger value="enquiry">Enquiry</TabsTrigger>
                  </TabsList>
                  <TabsContent value="booking" className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Date</label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className="w-full justify-start text-left font-normal border-nature-200"
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {date ? format(date, "PPP") : <span>Pick a date</span>}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={date}
                            onSelect={setDate}
                            initialFocus
                            className="rounded-md border"
                          />
                        </PopoverContent>
                      </Popover>
                    </div>

                    <div className="space-y-2">
                      <label htmlFor="guests" className="text-sm font-medium">
                        Guests
                      </label>
                      <div className="flex items-center">
                        <Button 
                          variant="outline" 
                          size="icon" 
                          className="border-nature-200"
                          onClick={() => setGuests(Math.max(1, guests - 1))}
                        >
                          -
                        </Button>
                        <div className="w-12 text-center font-medium">{guests}</div>
                        <Button 
                          variant="outline" 
                          size="icon" 
                          className="border-nature-200"
                          onClick={() => setGuests(Math.min(10, guests + 1))}
                        >
                          +
                        </Button>
                      </div>
                    </div>

                    <Button 
                      className="w-full bg-nature-600 hover:bg-nature-700 text-white"
                      onClick={handleBookNow}
                    >
                      Book Now
                    </Button>

                    <div className="space-y-4 pt-4 border-t border-nature-100">
                      <div className="flex justify-between">
                        <span>₹{experience.price} × {guests} guest{guests > 1 ? 's' : ''}</span>
                        <span>₹{experience.price * guests}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Service fee</span>
                        <span>₹{Math.round(experience.price * guests * 0.1)}</span>
                      </div>
                      <div className="flex justify-between font-medium pt-4 border-t border-nature-100">
                        <span>Total</span>
                        <span>₹{experience.price * guests + Math.round(experience.price * guests * 0.1)}</span>
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="enquiry" className="space-y-4">
                    <Input placeholder="Your Name" className="border-nature-200" />
                    <Input placeholder="Your Email" type="email" className="border-nature-200" />
                    <Input placeholder="Your Phone" type="tel" className="border-nature-200" />
                    <Input placeholder="Your Message" className="border-nature-200" />
                    <Button className="w-full bg-nature-600 hover:bg-nature-700 text-white">
                      Send Enquiry
                    </Button>
                  </TabsContent>
                </Tabs>

                <div className="text-center text-sm text-muted-foreground">
                  <p>No charge until you book</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* More Experiences */}
      <section className="bg-nature-50 py-16 border-t border-nature-100">
        <div className="container">
          <h2 className="text-2xl font-semibold mb-8">More Experiences You Might Like</h2>
          <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((item) => (
              <Link to="/experiences/exp-123" key={item}>
                <div className="group rounded-lg overflow-hidden transition-all duration-300 hover:shadow-md">
                  <div className="aspect-[4/3] bg-nature-100 relative">
                    <div className="absolute inset-0 flex items-center justify-center">
                      <p className="text-nature-600 font-medium">Image</p>
                    </div>
                    <Badge className="absolute top-2 right-2 bg-white text-nature-800 hover:bg-white">
                      Cooking
                    </Badge>
                  </div>
                  <div className="p-4 bg-white">
                    <div className="flex justify-between">
                      <h3 className="font-medium group-hover:text-nature-700">Traditional Coffee Making</h3>
                      <div className="flex items-center">
                        <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                        <span className="text-sm ml-1">4.7</span>
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">Chikmagalur, Karnataka</p>
                    <div className="flex justify-between items-center">
                      <p className="font-medium">₹1,800 <span className="text-sm font-normal text-muted-foreground">/ person</span></p>
                      <span className="text-sm text-muted-foreground flex items-center">
                        <Clock className="h-3 w-3 mr-1" /> 3 hours
                      </span>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </MainLayout>
  );
}
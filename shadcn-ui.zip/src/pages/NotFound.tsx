import { Button } from "@/components/ui/button";
import { Leaf } from "lucide-react";
import { Link } from "react-router-dom";

export default function NotFound() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-nature-50 p-4">
      <div className="text-center space-y-6 max-w-md animate-in fade-in slide-up duration-700">
        <div className="flex justify-center">
          <div className="bg-nature-100 p-4 rounded-full">
            <Leaf className="h-16 w-16 text-nature-600 animate-leaf-sway" />
          </div>
        </div>
        
        <h1 className="text-4xl font-bold text-nature-800">Page Not Found</h1>
        
        <p className="text-muted-foreground">
          We couldn't find the page you were looking for. Perhaps you've wandered off the trail?
        </p>
        
        <Button asChild className="bg-nature-600 hover:bg-nature-700 text-white font-medium">
          <Link to="/">Back to Home</Link>
        </Button>
      </div>
    </div>
  );
}
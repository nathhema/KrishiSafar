import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Menu } from "lucide-react";

export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <header
      className={`sticky top-0 z-50 w-full transition-all duration-200 ${
        isScrolled
          ? "bg-background/95 backdrop-blur-md shadow-sm"
          : "bg-transparent"
      }`}
    >
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Link
            to="/"
            className="flex items-center gap-2 font-medium transition-colors"
          >
            <span className="text-2xl font-semibold tracking-tighter text-gradient-nature">
              KrishiSafar
            </span>
          </Link>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-6">
          <Link
            to="/stays"
            className="text-sm font-medium hover:text-primary transition-colors hover-lift"
          >
            Explore Stays
          </Link>
          <Link
            to="/experiences"
            className="text-sm font-medium hover:text-primary transition-colors hover-lift"
          >
            Experiences
          </Link>
          <Link
            to="/about"
            className="text-sm font-medium hover:text-primary transition-colors hover-lift"
          >
            Our Story
          </Link>
          <Link
            to="/contact"
            className="text-sm font-medium hover:text-primary transition-colors hover-lift"
          >
            Contact
          </Link>
          <Link
            to="/hosts"
            className="text-sm font-medium hover:text-primary transition-colors hover-lift"
          >
            For Hosts
          </Link>
        </nav>

        <div className="flex items-center gap-4">
          <Button
            asChild
            variant="outline"
            className="hidden md:flex border-nature-600 text-nature-700 hover:text-nature-800 hover:bg-nature-50"
          >
            <Link to="/login">Sign In</Link>
          </Button>
          <Button
            asChild
            className="hidden md:flex bg-nature-600 text-white hover:bg-nature-700"
          >
            <Link to="/register">Join Us</Link>
          </Button>

          {/* Mobile Menu */}
          <Sheet>
            <SheetTrigger asChild>
              <Button
                variant="outline"
                size="icon"
                className="md:hidden border-nature-200"
              >
                <Menu className="h-5 w-5 text-nature-700" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent className="bg-nature-50">
              <SheetHeader>
                <SheetTitle className="text-gradient-nature">KrishiSafar</SheetTitle>
              </SheetHeader>
              <div className="flex flex-col space-y-4 mt-8">
                <Link
                  to="/stays"
                  className="text-base font-medium hover:text-primary py-2"
                >
                  Explore Stays
                </Link>
                <Link
                  to="/experiences"
                  className="text-base font-medium hover:text-primary py-2"
                >
                  Experiences
                </Link>
                <Link
                  to="/about"
                  className="text-base font-medium hover:text-primary py-2"
                >
                  Our Story
                </Link>
                <Link
                  to="/contact"
                  className="text-base font-medium hover:text-primary py-2"
                >
                  Contact
                </Link>
                <Link
                  to="/hosts"
                  className="text-base font-medium hover:text-primary py-2"
                >
                  For Hosts
                </Link>
                <hr className="border-nature-200" />
                <Link
                  to="/login"
                  className="text-base font-medium hover:text-primary py-2"
                >
                  Sign In
                </Link>
                <Button
                  asChild
                  className="bg-nature-600 text-white hover:bg-nature-700 mt-2"
                >
                  <Link to="/register">Join Us</Link>
                </Button>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
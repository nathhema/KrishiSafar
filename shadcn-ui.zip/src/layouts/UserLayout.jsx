import { useEffect } from "react";
import { Outlet, useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { 
  BookOpen, 
  Home, 
  LogOut, 
  Menu, 
  MessageSquare, 
  Search, 
  User, 
  Heart 
} from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Link, NavLink } from "react-router-dom";

export default function UserLayout() {
  const { user, isAuthenticated, logout, isUser } = useAuth();
  const navigate = useNavigate();

  // Protect routes - redirect if not authenticated or not a user
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/auth/login');
    } else if (!isUser) {
      // If authenticated but not a user, redirect based on role
      if (user?.type === 'farmer') {
        navigate('/farmer/dashboard');
      } else if (user?.type === 'admin') {
        navigate('/system/dashboard');
      }
    }
  }, [isAuthenticated, isUser, user, navigate]);

  // Don't render anything while checking authentication
  if (!isAuthenticated || !isUser) return null;

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Sidebar - Hidden on mobile */}
      <aside className="hidden md:flex w-64 flex-col fixed inset-y-0 bg-white border-r border-gray-200 pt-5 pb-4">
        <div className="flex items-center px-6 mb-6">
          <Link to="/" className="text-2xl font-semibold text-gradient-nature">KrishiSafar</Link>
        </div>
        
        <div className="px-4 mb-6">
          <div className="flex items-center p-3 bg-nature-50 rounded-lg">
            <div className="flex-shrink-0">
              <img 
                src={user?.profilePic || "https://placehold.co/40x40?text=U"} 
                alt={user?.name} 
                className="w-10 h-10 rounded-full object-cover"
              />
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium">{user?.name}</p>
              <p className="text-xs text-muted-foreground">{user?.email}</p>
            </div>
          </div>
        </div>
        
        <nav className="flex-1 px-3 space-y-1">
          <NavLink 
            to="/user/dashboard" 
            className={({isActive}) => `flex items-center px-3 py-2 rounded-md text-sm ${isActive ? 'bg-nature-100 text-nature-700' : 'text-gray-700 hover:bg-gray-100'}`}
          >
            <Home className="mr-3 h-4 w-4" />
            Dashboard
          </NavLink>
          
          <NavLink 
            to="/user/bookings" 
            className={({isActive}) => `flex items-center px-3 py-2 rounded-md text-sm ${isActive ? 'bg-nature-100 text-nature-700' : 'text-gray-700 hover:bg-gray-100'}`}
          >
            <BookOpen className="mr-3 h-4 w-4" />
            My Bookings
          </NavLink>
          
          <NavLink 
            to="/user/favorites" 
            className={({isActive}) => `flex items-center px-3 py-2 rounded-md text-sm ${isActive ? 'bg-nature-100 text-nature-700' : 'text-gray-700 hover:bg-gray-100'}`}
          >
            <Heart className="mr-3 h-4 w-4" />
            Favorites
          </NavLink>
          
          <NavLink 
            to="/user/messages" 
            className={({isActive}) => `flex items-center px-3 py-2 rounded-md text-sm ${isActive ? 'bg-nature-100 text-nature-700' : 'text-gray-700 hover:bg-gray-100'}`}
          >
            <MessageSquare className="mr-3 h-4 w-4" />
            Messages
          </NavLink>
          
          <NavLink 
            to="/user/profile" 
            className={({isActive}) => `flex items-center px-3 py-2 rounded-md text-sm ${isActive ? 'bg-nature-100 text-nature-700' : 'text-gray-700 hover:bg-gray-100'}`}
          >
            <User className="mr-3 h-4 w-4" />
            Profile
          </NavLink>
        </nav>
        
        <div className="px-3 mt-6">
          <Button 
            variant="outline" 
            className="w-full justify-start text-gray-700" 
            onClick={logout}
          >
            <LogOut className="mr-3 h-4 w-4" />
            Logout
          </Button>
        </div>
      </aside>
      
      {/* Main content */}
      <div className="md:ml-64 flex-1 flex flex-col min-h-screen">
        {/* Mobile header */}
        <header className="bg-white border-b border-gray-200 md:hidden">
          <div className="flex items-center justify-between p-4">
            <Link to="/" className="text-xl font-semibold text-gradient-nature">
              KrishiSafar
            </Link>
            
            <div className="flex items-center space-x-2">
              <Button 
                variant="ghost" 
                size="icon" 
                className="text-gray-700"
                asChild
              >
                <Link to="/stays">
                  <Search className="h-5 w-5" />
                </Link>
              </Button>
              
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="text-gray-700">
                    <Menu className="h-5 w-5" />
                  </Button>
                </SheetTrigger>
                <SheetContent>
                  <SheetHeader className="mb-4">
                    <SheetTitle className="text-gradient-nature">
                      KrishiSafar
                    </SheetTitle>
                  </SheetHeader>
                  
                  <div className="flex items-center p-3 bg-nature-50 rounded-lg mb-6">
                    <div className="flex-shrink-0">
                      <img 
                        src={user?.profilePic || "https://placehold.co/40x40?text=U"} 
                        alt={user?.name} 
                        className="w-10 h-10 rounded-full object-cover"
                      />
                    </div>
                    <div className="ml-3">
                      <p className="text-sm font-medium">{user?.name}</p>
                      <p className="text-xs text-muted-foreground">{user?.email}</p>
                    </div>
                  </div>
                  
                  <nav className="space-y-3">
                    <Link 
                      to="/user/dashboard" 
                      className="flex items-center px-3 py-2 rounded-md text-base"
                    >
                      <Home className="mr-3 h-5 w-5" />
                      Dashboard
                    </Link>
                    
                    <Link 
                      to="/user/bookings" 
                      className="flex items-center px-3 py-2 rounded-md text-base"
                    >
                      <BookOpen className="mr-3 h-5 w-5" />
                      My Bookings
                    </Link>
                    
                    <Link 
                      to="/user/favorites" 
                      className="flex items-center px-3 py-2 rounded-md text-base"
                    >
                      <Heart className="mr-3 h-5 w-5" />
                      Favorites
                    </Link>
                    
                    <Link 
                      to="/user/messages" 
                      className="flex items-center px-3 py-2 rounded-md text-base"
                    >
                      <MessageSquare className="mr-3 h-5 w-5" />
                      Messages
                    </Link>
                    
                    <Link 
                      to="/user/profile" 
                      className="flex items-center px-3 py-2 rounded-md text-base"
                    >
                      <User className="mr-3 h-5 w-5" />
                      Profile
                    </Link>
                    
                    <button 
                      onClick={logout}
                      className="flex w-full items-center px-3 py-2 rounded-md text-base"
                    >
                      <LogOut className="mr-3 h-5 w-5" />
                      Logout
                    </button>
                  </nav>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </header>
        
        {/* Page content */}
        <main className="flex-1 p-5">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
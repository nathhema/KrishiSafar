import { useEffect } from "react";
import { Outlet, useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { 
  BarChart, 
  BookOpen, 
  Home, 
  LogOut, 
  Menu, 
  MessageSquare,
  Settings, 
  User,
  CalendarDays,
  MapPin
} from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Link, NavLink } from "react-router-dom";

export default function FarmerLayout() {
  const { user, isAuthenticated, logout, isFarmer } = useAuth();
  const navigate = useNavigate();

  // Protect routes - redirect if not authenticated or not a farmer
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/auth/login');
    } else if (!isFarmer) {
      // If authenticated but not a farmer, redirect based on role
      if (user?.type === 'user') {
        navigate('/user/dashboard');
      } else if (user?.type === 'admin') {
        navigate('/system/dashboard');
      }
    }
  }, [isAuthenticated, isFarmer, user, navigate]);

  // Don't render anything while checking authentication
  if (!isAuthenticated || !isFarmer) return null;

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Sidebar - Hidden on mobile */}
      <aside className="hidden md:flex w-64 flex-col fixed inset-y-0 bg-white border-r border-gray-200 pt-5 pb-4">
        <div className="flex items-center px-6 mb-6">
          <Link to="/" className="text-2xl font-semibold text-gradient-nature">KrishiSafar</Link>
        </div>
        
        <div className="px-4 mb-6">
          <div className="flex items-center p-3 bg-nature-50 rounded-lg">
            <div className="flex-shrink-0">
              <img 
                src={user?.profilePic || "https://placehold.co/40x40?text=F"} 
                alt={user?.name} 
                className="w-10 h-10 rounded-full object-cover"
              />
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium">{user?.name}</p>
              <p className="text-xs text-muted-foreground">Farmer</p>
            </div>
          </div>
        </div>
        
        <nav className="flex-1 px-3 space-y-1">
          <NavLink 
            to="/farmer/dashboard" 
            className={({isActive}) => `flex items-center px-3 py-2 rounded-md text-sm ${isActive ? 'bg-nature-100 text-nature-700' : 'text-gray-700 hover:bg-gray-100'}`}
          >
            <Home className="mr-3 h-4 w-4" />
            Dashboard
          </NavLink>
          
          <NavLink 
            to="/farmer/bookings" 
            className={({isActive}) => `flex items-center px-3 py-2 rounded-md text-sm ${isActive ? 'bg-nature-100 text-nature-700' : 'text-gray-700 hover:bg-gray-100'}`}
          >
            <BookOpen className="mr-3 h-4 w-4" />
            Bookings
          </NavLink>
          
          <NavLink 
            to="/farmer/stays" 
            className={({isActive}) => `flex items-center px-3 py-2 rounded-md text-sm ${isActive ? 'bg-nature-100 text-nature-700' : 'text-gray-700 hover:bg-gray-100'}`}
          >
            <MapPin className="mr-3 h-4 w-4" />
            My Stays
          </NavLink>
          
          <NavLink 
            to="/farmer/experiences" 
            className={({isActive}) => `flex items-center px-3 py-2 rounded-md text-sm ${isActive ? 'bg-nature-100 text-nature-700' : 'text-gray-700 hover:bg-gray-100'}`}
          >
            <CalendarDays className="mr-3 h-4 w-4" />
            My Experiences
          </NavLink>
          
          <NavLink 
            to="/farmer/analytics" 
            className={({isActive}) => `flex items-center px-3 py-2 rounded-md text-sm ${isActive ? 'bg-nature-100 text-nature-700' : 'text-gray-700 hover:bg-gray-100'}`}
          >
            <BarChart className="mr-3 h-4 w-4" />
            Analytics
          </NavLink>
          
          <NavLink 
            to="/farmer/messages" 
            className={({isActive}) => `flex items-center px-3 py-2 rounded-md text-sm ${isActive ? 'bg-nature-100 text-nature-700' : 'text-gray-700 hover:bg-gray-100'}`}
          >
            <MessageSquare className="mr-3 h-4 w-4" />
            Messages
          </NavLink>
          
          <NavLink 
            to="/farmer/profile" 
            className={({isActive}) => `flex items-center px-3 py-2 rounded-md text-sm ${isActive ? 'bg-nature-100 text-nature-700' : 'text-gray-700 hover:bg-gray-100'}`}
          >
            <User className="mr-3 h-4 w-4" />
            Profile
          </NavLink>
          
          <NavLink 
            to="/farmer/settings" 
            className={({isActive}) => `flex items-center px-3 py-2 rounded-md text-sm ${isActive ? 'bg-nature-100 text-nature-700' : 'text-gray-700 hover:bg-gray-100'}`}
          >
            <Settings className="mr-3 h-4 w-4" />
            Settings
          </NavLink>
        </nav>
        
        <div className="px-3 mt-6">
          <Button 
            variant="outline" 
            className="w-full justify-start text-gray-700" 
            onClick={logout}
          >
            <LogOut className="mr-3 h-4 w-4" />
            Logout
          </Button>
        </div>
      </aside>
      
      {/* Main content */}
      <div className="md:ml-64 flex-1 flex flex-col min-h-screen">
        {/* Mobile header */}
        <header className="bg-white border-b border-gray-200 md:hidden">
          <div className="flex items-center justify-between p-4">
            <Link to="/" className="text-xl font-semibold text-gradient-nature">
              KrishiSafar
            </Link>
            
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="text-gray-700">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent>
                <SheetHeader className="mb-4">
                  <SheetTitle className="text-gradient-nature">
                    KrishiSafar
                  </SheetTitle>
                </SheetHeader>
                
                <div className="flex items-center p-3 bg-nature-50 rounded-lg mb-6">
                  <div className="flex-shrink-0">
                    <img 
                      src={user?.profilePic || "https://placehold.co/40x40?text=F"} 
                      alt={user?.name} 
                      className="w-10 h-10 rounded-full object-cover"
                    />
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium">{user?.name}</p>
                    <p className="text-xs text-muted-foreground">Farmer</p>
                  </div>
                </div>
                
                <nav className="space-y-3">
                  <Link 
                    to="/farmer/dashboard" 
                    className="flex items-center px-3 py-2 rounded-md text-base"
                  >
                    <Home className="mr-3 h-5 w-5" />
                    Dashboard
                  </Link>
                  
                  <Link 
                    to="/farmer/bookings" 
                    className="flex items-center px-3 py-2 rounded-md text-base"
                  >
                    <BookOpen className="mr-3 h-5 w-5" />
                    Bookings
                  </Link>
                  
                  <Link 
                    to="/farmer/stays" 
                    className="flex items-center px-3 py-2 rounded-md text-base"
                  >
                    <MapPin className="mr-3 h-5 w-5" />
                    My Stays
                  </Link>
                  
                  <Link 
                    to="/farmer/experiences" 
                    className="flex items-center px-3 py-2 rounded-md text-base"
                  >
                    <CalendarDays className="mr-3 h-5 w-5" />
                    My Experiences
                  </Link>
                  
                  <Link 
                    to="/farmer/analytics" 
                    className="flex items-center px-3 py-2 rounded-md text-base"
                  >
                    <BarChart className="mr-3 h-5 w-5" />
                    Analytics
                  </Link>
                  
                  <Link 
                    to="/farmer/messages" 
                    className="flex items-center px-3 py-2 rounded-md text-base"
                  >
                    <MessageSquare className="mr-3 h-5 w-5" />
                    Messages
                  </Link>
                  
                  <Link 
                    to="/farmer/profile" 
                    className="flex items-center px-3 py-2 rounded-md text-base"
                  >
                    <User className="mr-3 h-5 w-5" />
                    Profile
                  </Link>
                  
                  <Link 
                    to="/farmer/settings" 
                    className="flex items-center px-3 py-2 rounded-md text-base"
                  >
                    <Settings className="mr-3 h-5 w-5" />
                    Settings
                  </Link>
                  
                  <button 
                    onClick={logout}
                    className="flex w-full items-center px-3 py-2 rounded-md text-base"
                  >
                    <LogOut className="mr-3 h-5 w-5" />
                    Logout
                  </button>
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </header>
        
        {/* Page content */}
        <main className="flex-1 p-5">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
import { createContext, useContext, useEffect, useState } from 'react';
import authService from '../services/authService';
import { useNavigate } from 'react-router-dom';
import { useToast } from "@/components/ui/use-toast";

// Create the auth context
const AuthContext = createContext();

// Provider component for the auth context
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const { toast } = useToast();

  // Initialize user from localStorage on component mount
  useEffect(() => {
    const initAuth = async () => {
      try {
        const currentUser = authService.getCurrentUser();
        if (currentUser) {
          setUser(currentUser);
        }
      } catch (error) {
        console.error('Error initializing authentication:', error);
        // Clear potentially corrupted auth data
        authService.logout();
      } finally {
        setLoading(false);
      }
    };

    initAuth();
  }, []);

  // Login function
  const login = async (email, password) => {
    setLoading(true);
    try {
      const { user: authUser } = await authService.login(email, password);
      setUser(authUser);
      
      toast({
        title: "Login successful",
        description: `Welcome back, ${authUser.name}!`,
      });
      
      // Redirect based on user type
      if (authUser.type === 'farmer') {
        navigate('/farmer/dashboard');
      } else if (authUser.type === 'admin') {
        navigate('/system/dashboard');
      } else {
        navigate('/user/dashboard');
      }
      
      return authUser;
    } catch (error) {
      toast({
        title: "Login failed",
        description: error.message || "Please check your credentials and try again.",
        variant: "destructive"
      });
      throw error;
    } finally {
      setLoading(false);
    }
  };

  // Register function
  const register = async (userData) => {
    setLoading(true);
    try {
      const { user: newUser } = await authService.register(userData);
      setUser(newUser);
      
      toast({
        title: "Registration successful",
        description: `Welcome to KrishiSafar, ${newUser.name}!`,
      });
      
      // Redirect based on user type
      if (newUser.type === 'farmer') {
        navigate('/farmer/dashboard');
      } else {
        navigate('/user/dashboard');
      }
      
      return newUser;
    } catch (error) {
      toast({
        title: "Registration failed",
        description: error.message || "Please check your information and try again.",
        variant: "destructive"
      });
      throw error;
    } finally {
      setLoading(false);
    }
  };

  // Logout function
  const logout = () => {
    authService.logout();
    setUser(null);
    
    toast({
      title: "Logged out",
      description: "You have been successfully logged out.",
    });
    
    navigate('/');
  };

  // Context value
  const contextValue = {
    user,
    loading,
    isAuthenticated: !!user,
    login,
    register,
    logout,
    isUser: user?.type === 'user',
    isFarmer: user?.type === 'farmer',
    isAdmin: user?.type === 'admin',
  };

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  );
}

// Hook for using auth context
export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
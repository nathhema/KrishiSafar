import { Toaster } from '@/components/ui/sonner';
import { TooltipProvider } from '@/components/ui/tooltip';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import HomePage from './pages/Index';
import NotFound from './pages/NotFound';
import AboutPage from './pages/About';
import StaysPage from './pages/Stays';
import ExperiencesPage from './pages/Experiences';
import ContactPage from './pages/Contact';
import StayDetailPage from './pages/StayDetail';
import ExperienceDetailPage from './pages/ExperienceDetail';
import { lazy, Suspense } from 'react';

// Using lazy loading for future pages
const HostsPage = lazy(() => import('./pages/Hosts'));

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/contact" element={<ContactPage />} />
          
          {/* Stays routes */}
          <Route path="/stays" element={<StaysPage />} />
          <Route path="/stays/:stayId" element={<StayDetailPage />} />
          
          {/* Experiences routes */}
          <Route path="/experiences" element={<ExperiencesPage />} />
          <Route path="/experiences/:experienceId" element={<ExperienceDetailPage />} />
          
          {/* Hosts route */}
          <Route path="/hosts" element={
            <Suspense fallback={<div className="min-h-screen flex items-center justify-center">Loading...</div>}>
              <HostsPage />
            </Suspense>
          } />
          
          {/* 404 route */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;

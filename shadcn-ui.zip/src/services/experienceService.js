// Experience service to handle experience-related operations
import { experiences, bookings } from './mockData';

// Simulate API delay
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// Experience service
const experienceService = {
  // Get all experiences
  async getAllExperiences() {
    await delay(500); // Simulate API delay
    return [...experiences];
  },
  
  // Get experience by ID
  async getExperienceById(id) {
    await delay(300);
    const experience = experiences.find(exp => exp.id === id);
    if (!experience) {
      throw new Error('Experience not found');
    }
    return { ...experience };
  },
  
  // Search experiences by various criteria
  async searchExperiences(searchCriteria) {
    await delay(800);
    
    let filteredExperiences = [...experiences];
    
    if (searchCriteria.location) {
      filteredExperiences = filteredExperiences.filter(exp => 
        exp.location.toLowerCase().includes(searchCriteria.location.toLowerCase()) ||
        (exp.address.city && exp.address.city.toLowerCase().includes(searchCriteria.location.toLowerCase())) ||
        (exp.address.state && exp.address.state.toLowerCase().includes(searchCriteria.location.toLowerCase()))
      );
    }
    
    if (searchCriteria.date) {
      // In a real app, we would check availability properly
      // This is a simplified version
      filteredExperiences = filteredExperiences.filter(exp => {
        // Check if experience has any availability dates that match the requested date
        return exp.availability.some(slot => {
          return slot.date === searchCriteria.date;
        });
      });
    }
    
    if (searchCriteria.participants) {
      filteredExperiences = filteredExperiences.filter(exp => 
        exp.maxParticipants >= searchCriteria.participants
      );
    }
    
    if (searchCriteria.tags && searchCriteria.tags.length) {
      filteredExperiences = filteredExperiences.filter(exp => 
        searchCriteria.tags.some(tag => exp.tags.includes(tag))
      );
    }
    
    if (searchCriteria.priceMin) {
      filteredExperiences = filteredExperiences.filter(exp => exp.price >= searchCriteria.priceMin);
    }
    
    if (searchCriteria.priceMax) {
      filteredExperiences = filteredExperiences.filter(exp => exp.price <= searchCriteria.priceMax);
    }
    
    if (searchCriteria.duration) {
      filteredExperiences = filteredExperiences.filter(exp => 
        exp.duration.toLowerCase().includes(searchCriteria.duration.toLowerCase())
      );
    }
    
    return filteredExperiences;
  },
  
  // Get experiences for a specific farmer
  async getFarmerExperiences(farmerId) {
    await delay(500);
    return experiences.filter(exp => exp.farmerId === farmerId);
  },
  
  // Check if experience is available for a specific date and participant count
  async checkAvailability(experienceId, date, participants) {
    await delay(300);
    
    const experience = experiences.find(exp => exp.id === experienceId);
    if (!experience) {
      throw new Error('Experience not found');
    }
    
    // Check if the experience has availability for the requested date
    const availabilitySlot = experience.availability.find(slot => slot.date === date);
    if (!availabilitySlot) {
      return {
        available: false,
        reason: 'Experience is not available on the selected date'
      };
    }
    
    // Check existing bookings to determine remaining capacity
    const existingBookings = bookings.filter(
      booking => booking.itemId === experienceId && 
                booking.itemType === 'experience' && 
                booking.date === date && 
                booking.status !== 'cancelled'
    );
    
    const bookedParticipants = existingBookings.reduce(
      (total, booking) => total + booking.participants, 0
    );
    
    const remainingCapacity = experience.maxParticipants - bookedParticipants;
    
    if (remainingCapacity < participants) {
      return {
        available: false,
        reason: `Only ${remainingCapacity} spots available for this date`
      };
    }
    
    return {
      available: true,
      reason: null
    };
  }
};

export default experienceService;
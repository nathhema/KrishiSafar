// Base API service for handling HTTP requests
import axios from 'axios';

// Create axios instance with default config
const api = axios.create({
  baseURL: '/api', // In a real app, this would be the actual API URL
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  }
});

// Request interceptor - add auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('krishiSafarToken');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor - handle common errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    // Handle auth errors
    if (error.response && error.response.status === 401) {
      localStorage.removeItem('krishiSafarToken');
      // In a real app, redirect to login
    }
    return Promise.reject(error);
  }
);

export default api;
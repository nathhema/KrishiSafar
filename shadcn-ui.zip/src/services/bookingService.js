// Booking service to handle booking-related operations
import { bookings, stays, experiences } from './mockData';

// Simulate API delay
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// Generate a random booking ID
const generateBookingId = () => {
  return 'book' + Date.now().toString(36) + Math.random().toString(36).substring(2, 5);
};

// Calculate total amount for a stay booking
const calculateStayTotal = (stay, startDate, endDate, guests) => {
  const start = new Date(startDate);
  const end = new Date(endDate);
  const nights = Math.ceil((end - start) / (1000 * 60 * 60 * 24));
  return stay.price * nights;
};

// Calculate total amount for an experience booking
const calculateExperienceTotal = (experience, participants) => {
  return experience.price * participants;
};

// Booking service
const bookingService = {
  // Get all bookings for a user
  async getUserBookings(userId) {
    await delay(500);
    return bookings.filter(booking => booking.userId === userId);
  },
  
  // Get booking by ID
  async getBookingById(bookingId) {
    await delay(300);
    const booking = bookings.find(booking => booking.id === bookingId);
    if (!booking) {
      throw new Error('Booking not found');
    }
    
    // Add item details to the booking
    let itemDetails = null;
    if (booking.itemType === 'stay') {
      itemDetails = stays.find(stay => stay.id === booking.itemId);
    } else if (booking.itemType === 'experience') {
      itemDetails = experiences.find(exp => exp.id === booking.itemId);
    }
    
    return { ...booking, itemDetails };
  },
  
  // Get all bookings for a farmer
  async getFarmerBookings(farmerId) {
    await delay(500);
    
    // Find all stays and experiences owned by this farmer
    const farmerStays = stays.filter(stay => stay.farmerId === farmerId);
    const farmerExperiences = experiences.filter(exp => exp.farmerId === farmerId);
    
    // Get all bookings for these items
    const stayBookings = bookings.filter(
      booking => booking.itemType === 'stay' && 
        farmerStays.some(stay => stay.id === booking.itemId)
    );
    
    const experienceBookings = bookings.filter(
      booking => booking.itemType === 'experience' && 
        farmerExperiences.some(exp => exp.id === booking.itemId)
    );
    
    // Combine and add details
    const allBookings = [...stayBookings, ...experienceBookings];
    
    // Add item details to each booking
    return allBookings.map(booking => {
      let itemDetails = null;
      if (booking.itemType === 'stay') {
        itemDetails = stays.find(stay => stay.id === booking.itemId);
      } else if (booking.itemType === 'experience') {
        itemDetails = experiences.find(exp => exp.id === booking.itemId);
      }
      
      return { ...booking, itemDetails };
    });
  },
  
  // Create a new stay booking
  async createStayBooking(userId, stayId, startDate, endDate, guests) {
    await delay(1000);
    
    // Find the stay
    const stay = stays.find(stay => stay.id === stayId);
    if (!stay) {
      throw new Error('Stay not found');
    }
    
    // Calculate total price
    const totalAmount = calculateStayTotal(stay, startDate, endDate, guests);
    
    // Create booking object
    const newBooking = {
      id: generateBookingId(),
      userId,
      itemType: 'stay',
      itemId: stayId,
      startDate,
      endDate,
      guests,
      totalAmount,
      currency: stay.currency,
      status: 'confirmed', // In a real app, this might start as 'pending'
      paymentStatus: 'paid', // In a real app, this would depend on payment process
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    // In a real app, this would be added to the database
    // For now, we just return the new booking
    
    return { ...newBooking };
  },
  
  // Create a new experience booking
  async createExperienceBooking(userId, experienceId, date, participants) {
    await delay(1000);
    
    // Find the experience
    const experience = experiences.find(exp => exp.id === experienceId);
    if (!experience) {
      throw new Error('Experience not found');
    }
    
    // Calculate total price
    const totalAmount = calculateExperienceTotal(experience, participants);
    
    // Create booking object
    const newBooking = {
      id: generateBookingId(),
      userId,
      itemType: 'experience',
      itemId: experienceId,
      date,
      participants,
      totalAmount,
      currency: experience.currency,
      status: 'confirmed', // In a real app, this might start as 'pending'
      paymentStatus: 'paid', // In a real app, this would depend on payment process
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    // In a real app, this would be added to the database
    // For now, we just return the new booking
    
    return { ...newBooking };
  },
  
  // Cancel a booking
  async cancelBooking(bookingId, userId) {
    await delay(800);
    
    // Find the booking
    const booking = bookings.find(booking => booking.id === bookingId && booking.userId === userId);
    if (!booking) {
      throw new Error('Booking not found or unauthorized');
    }
    
    // Check if booking can be cancelled
    if (booking.status === 'cancelled') {
      throw new Error('Booking is already cancelled');
    }
    
    if (booking.status === 'completed') {
      throw new Error('Completed bookings cannot be cancelled');
    }
    
    // Update booking status
    const updatedBooking = {
      ...booking,
      status: 'cancelled',
      updatedAt: new Date().toISOString()
    };
    
    // In a real app, this would update the database
    // For now, we just return the updated booking
    
    return { ...updatedBooking };
  }
};

export default bookingService;
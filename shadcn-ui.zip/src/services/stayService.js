// Stay service to handle stay-related operations
import { stays, bookings } from './mockData';

// Simulate API delay
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// Stay service
const stayService = {
  // Get all stays
  async getAllStays() {
    await delay(500); // Simulate API delay
    return [...stays];
  },
  
  // Get stay by ID
  async getStayById(id) {
    await delay(300);
    const stay = stays.find(stay => stay.id === id);
    if (!stay) {
      throw new Error('Stay not found');
    }
    return { ...stay };
  },
  
  // Search stays by various criteria
  async searchStays(searchCriteria) {
    await delay(800);
    
    let filteredStays = [...stays];
    
    if (searchCriteria.location) {
      filteredStays = filteredStays.filter(stay => 
        stay.location.toLowerCase().includes(searchCriteria.location.toLowerCase()) ||
        stay.address.city.toLowerCase().includes(searchCriteria.location.toLowerCase()) ||
        stay.address.state.toLowerCase().includes(searchCriteria.location.toLowerCase())
      );
    }
    
    if (searchCriteria.startDate && searchCriteria.endDate) {
      // In a real app, we would check availability properly
      // This is a simplified version
      filteredStays = filteredStays.filter(stay => {
        // Check if stay has any availability periods that include the requested dates
        return stay.availability.some(period => {
          const periodStart = new Date(period.start);
          const periodEnd = new Date(period.end);
          const requestStart = new Date(searchCriteria.startDate);
          const requestEnd = new Date(searchCriteria.endDate);
          
          return requestStart >= periodStart && requestEnd <= periodEnd;
        });
      });
    }
    
    if (searchCriteria.guests) {
      filteredStays = filteredStays.filter(stay => 
        stay.maxGuests >= searchCriteria.guests
      );
    }
    
    if (searchCriteria.tags && searchCriteria.tags.length) {
      filteredStays = filteredStays.filter(stay => 
        searchCriteria.tags.some(tag => stay.tags.includes(tag))
      );
    }
    
    if (searchCriteria.priceMin) {
      filteredStays = filteredStays.filter(stay => stay.price >= searchCriteria.priceMin);
    }
    
    if (searchCriteria.priceMax) {
      filteredStays = filteredStays.filter(stay => stay.price <= searchCriteria.priceMax);
    }
    
    if (searchCriteria.amenities && searchCriteria.amenities.length) {
      filteredStays = filteredStays.filter(stay => 
        searchCriteria.amenities.every(amenity => stay.amenities.includes(amenity))
      );
    }
    
    return filteredStays;
  },
  
  // Get stays for a specific farmer
  async getFarmerStays(farmerId) {
    await delay(500);
    return stays.filter(stay => stay.farmerId === farmerId);
  },
  
  // Check if stay is available for specific dates
  async checkAvailability(stayId, startDate, endDate) {
    await delay(300);
    
    const stay = stays.find(stay => stay.id === stayId);
    if (!stay) {
      throw new Error('Stay not found');
    }
    
    const requestStart = new Date(startDate);
    const requestEnd = new Date(endDate);
    
    // Check if the stay has any availability periods that include the requested dates
    const isInAvailabilityPeriod = stay.availability.some(period => {
      const periodStart = new Date(period.start);
      const periodEnd = new Date(period.end);
      return requestStart >= periodStart && requestEnd <= periodEnd;
    });
    
    // Check if there are no overlapping bookings
    const existingBookings = bookings.filter(
      booking => booking.itemId === stayId && 
                booking.itemType === 'stay' && 
                booking.status !== 'cancelled'
    );
    
    const hasOverlappingBooking = existingBookings.some(booking => {
      const bookingStart = new Date(booking.startDate);
      const bookingEnd = new Date(booking.endDate);
      
      // Check if dates overlap
      return (
        (requestStart >= bookingStart && requestStart < bookingEnd) ||
        (requestEnd > bookingStart && requestEnd <= bookingEnd) ||
        (requestStart <= bookingStart && requestEnd >= bookingEnd)
      );
    });
    
    return {
      available: isInAvailabilityPeriod && !hasOverlappingBooking,
      reason: !isInAvailabilityPeriod 
        ? 'Stay is not available for the selected dates' 
        : hasOverlappingBooking 
        ? 'Stay is already booked for the selected dates'
        : null
    };
  }
};

export default stayService;
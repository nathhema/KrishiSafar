// Mock data for the application
// In a real app, this would be fetched from an API

// Mock Users
export const users = [
  {
    id: 'user1',
    email: 'user@example.com',
    password: 'password123', // In a real app, passwords would be hashed and not stored like this
    name: 'Demo User',
    phone: '9876543210',
    type: 'user',
    profilePic: '/images/useravatar.jpg'
  },
  {
    id: 'farmer1',
    email: 'farmer@example.com',
    password: 'password123',
    name: 'Demo Farmer',
    phone: '9876543211',
    type: 'farmer',
    farmName: 'Green Meadows Farm',
    farmLocation: 'Karnataka',
    farmDescription: 'A beautiful organic farm with various crops and farm animals.',
    profilePic: '/assets/images/avatars/farmer1.jpg'
  },
  {
    id: 'admin1',
    email: 'admin@example.com',
    password: 'admin123',
    name: 'Admin User',
    type: 'admin',
    profilePic: '/assets/images/avatars/admin1.jpg'
  }
];

// Mock Stays
export const stays = [
  {
    id: 'stay1',
    farmerId: 'farmer1',
    title: 'Sunset Valley Farm Retreat',
    description: 'Experience the beauty of rural living in our farm retreat surrounded by lush green fields and mountains.',
    location: 'Himachal Pradesh',
    address: {
      street: 'Village Chail',
      city: 'Shimla',
      state: 'Himachal Pradesh',
      zipCode: '171202',
      coordinates: {
        lat: 30.9677,
        lng: 77.1975
      }
    },
    price: 2500,
    currency: 'INR',
    rating: 4.9,
    images: [
      '/assets/images/stays/farm-retreat-1.jpg',
      '/assets/images/stays/farm-retreat-2.jpg',
      '/assets/images/stays/farm-retreat-3.jpg'
    ],
    amenities: ['Wifi', 'Kitchen', 'Farm Tour', 'Organic Meals', 'Mountain View'],
    maxGuests: 4,
    bedrooms: 2,
    bathrooms: 1,
    tags: ['Farm Stay', 'Mountains'],
    availability: [
      {
        start: '2023-09-01',
        end: '2023-12-31'
      }
    ],
    reviews: [
      {
        userId: 'user1',
        rating: 5,
        comment: 'Amazing experience with beautiful views and great hospitality.',
        date: '2023-07-15'
      }
    ],
    createdAt: '2023-01-15',
    updatedAt: '2023-08-10'
  },
  {
    id: 'stay2',
    farmerId: 'farmer1',
    title: 'Green Meadows Eco Lodge',
    description: 'An eco-friendly lodge situated amidst a working organic farm with waterfront views.',
    location: 'Kerala',
    address: {
      street: 'Eco Farm Road',
      city: 'Kochi',
      state: 'Kerala',
      zipCode: '682021',
      coordinates: {
        lat: 9.9312,
        lng: 76.2673
      }
    },
    price: 3200,
    currency: 'INR',
    rating: 4.8,
    images: [
      '/assets/images/stays/eco-lodge-1.jpg',
      '/assets/images/stays/eco-lodge-2.jpg',
      '/assets/images/stays/eco-lodge-3.jpg'
    ],
    amenities: ['Wifi', 'Kitchen', 'Farm Tour', 'Organic Meals', 'Waterfront'],
    maxGuests: 6,
    bedrooms: 3,
    bathrooms: 2,
    tags: ['Eco-friendly', 'Waterfront'],
    availability: [
      {
        start: '2023-10-01',
        end: '2023-12-31'
      }
    ],
    reviews: [
      {
        userId: 'user1',
        rating: 4,
        comment: 'Beautiful location with a great learning experience about organic farming.',
        date: '2023-06-20'
      }
    ],
    createdAt: '2023-02-10',
    updatedAt: '2023-08-15'
  },
  {
    id: 'stay3',
    farmerId: 'farmer1',
    title: 'Organic Orchard Homestay',
    description: 'A cozy homestay within an organic orchard where you can pick fresh fruits and learn about sustainable farming.',
    location: 'Karnataka',
    address: {
      street: 'Orchard Lane',
      city: 'Coorg',
      state: 'Karnataka',
      zipCode: '571201',
      coordinates: {
        lat: 12.4244,
        lng: 75.7382
      }
    },
    price: 1800,
    currency: 'INR',
    rating: 4.7,
    images: [
      '/assets/images/stays/orchard-homestay-1.jpg',
      '/assets/images/stays/orchard-homestay-2.jpg',
      '/assets/images/stays/orchard-homestay-3.jpg'
    ],
    amenities: ['Wifi', 'Kitchen', 'Orchard Tour', 'Organic Meals', 'Fruit Picking'],
    maxGuests: 3,
    bedrooms: 1,
    bathrooms: 1,
    tags: ['Organic Farm', 'Family-friendly'],
    availability: [
      {
        start: '2023-09-15',
        end: '2023-11-30'
      }
    ],
    reviews: [
      {
        userId: 'user1',
        rating: 5,
        comment: 'Our kids loved the fruit picking experience. Great family getaway!',
        date: '2023-08-05'
      }
    ],
    createdAt: '2023-03-05',
    updatedAt: '2023-08-10'
  },
  {
    id: 'stay4',
    farmerId: 'farmer1',
    title: 'Mountain View Cottage',
    description: 'A secluded cottage with breathtaking mountain views, perfect for hiking enthusiasts and nature lovers.',
    location: 'Uttarakhand',
    address: {
      street: 'Mountain View Road',
      city: 'Nainital',
      state: 'Uttarakhand',
      zipCode: '263001',
      coordinates: {
        lat: 29.3803,
        lng: 79.4636
      }
    },
    price: 2800,
    currency: 'INR',
    rating: 4.9,
    images: [
      '/assets/images/stays/mountain-cottage-1.jpg',
      '/assets/images/stays/mountain-cottage-2.jpg',
      '/assets/images/stays/mountain-cottage-3.jpg'
    ],
    amenities: ['Wifi', 'Kitchen', 'Hiking Trails', 'Mountain View', 'Bonfire'],
    maxGuests: 2,
    bedrooms: 1,
    bathrooms: 1,
    tags: ['Mountain View', 'Hiking'],
    availability: [
      {
        start: '2023-10-01',
        end: '2023-12-15'
      }
    ],
    reviews: [
      {
        userId: 'user1',
        rating: 5,
        comment: 'The view is spectacular! Perfect place to disconnect and enjoy nature.',
        date: '2023-07-25'
      }
    ],
    createdAt: '2023-04-20',
    updatedAt: '2023-08-12'
  }
];

// Mock Experiences
export const experiences = [
  {
    id: 'exp1',
    farmerId: 'farmer1',
    title: 'Organic Farming Workshop',
    description: 'Learn the basics of organic farming, including soil preparation, composting, and natural pest control.',
    location: 'Multiple Locations',
    address: {
      city: 'Bangalore',
      state: 'Karnataka',
      coordinates: {
        lat: 12.9716,
        lng: 77.5946
      }
    },
    price: 1200,
    currency: 'INR',
    rating: 4.8,
    images: [
      '/assets/images/experiences/farming-workshop-1.jpg',
      '/assets/images/experiences/farming-workshop-2.jpg'
    ],
    duration: 'Half-day',
    included: ['Farming tools', 'Organic seeds', 'Refreshments'],
    requirements: ['Comfortable clothing', 'Hat', 'Sunscreen'],
    maxParticipants: 15,
    tags: ['Workshop', 'Educational', 'Hands-on'],
    availability: [
      {
        date: '2023-09-15',
        startTime: '09:00',
        endTime: '13:00'
      },
      {
        date: '2023-09-30',
        startTime: '09:00',
        endTime: '13:00'
      }
    ],
    reviews: [
      {
        userId: 'user1',
        rating: 5,
        comment: 'Very informative workshop with hands-on activities. Great for beginners!',
        date: '2023-08-02'
      }
    ],
    createdAt: '2023-05-10',
    updatedAt: '2023-08-10'
  },
  {
    id: 'exp2',
    farmerId: 'farmer1',
    title: 'Traditional Cooking Class',
    description: 'Learn to cook traditional Indian dishes using farm-fresh organic ingredients.',
    location: 'Multiple Locations',
    address: {
      city: 'Jaipur',
      state: 'Rajasthan',
      coordinates: {
        lat: 26.9124,
        lng: 75.7873
      }
    },
    price: 1500,
    currency: 'INR',
    rating: 4.7,
    images: [
      '/assets/images/experiences/cooking-class-1.jpg',
      '/assets/images/experiences/cooking-class-2.jpg'
    ],
    duration: '3 hours',
    included: ['Ingredients', 'Recipes', 'Meal'],
    requirements: ['None'],
    maxParticipants: 10,
    tags: ['Cooking', 'Cultural', 'Food'],
    availability: [
      {
        date: '2023-09-20',
        startTime: '15:00',
        endTime: '18:00'
      },
      {
        date: '2023-10-05',
        startTime: '15:00',
        endTime: '18:00'
      }
    ],
    reviews: [
      {
        userId: 'user1',
        rating: 4,
        comment: 'Delicious recipes and great instruction. Loved cooking with fresh farm ingredients!',
        date: '2023-07-18'
      }
    ],
    createdAt: '2023-06-05',
    updatedAt: '2023-08-15'
  },
  {
    id: 'exp3',
    farmerId: 'farmer1',
    title: 'Guided Nature Walks',
    description: 'Explore the local flora and fauna with an experienced guide who will share knowledge about the ecosystem.',
    location: 'Multiple Locations',
    address: {
      city: 'Munnar',
      state: 'Kerala',
      coordinates: {
        lat: 10.0889,
        lng: 77.0595
      }
    },
    price: 800,
    currency: 'INR',
    rating: 4.9,
    images: [
      '/assets/images/experiences/nature-walk-1.jpg',
      '/assets/images/experiences/nature-walk-2.jpg'
    ],
    duration: '2 hours',
    included: ['Guide', 'Binoculars', 'Water'],
    requirements: ['Comfortable walking shoes', 'Hat', 'Sunscreen'],
    maxParticipants: 12,
    tags: ['Nature', 'Walking', 'Educational'],
    availability: [
      {
        date: '2023-09-25',
        startTime: '07:00',
        endTime: '09:00'
      },
      {
        date: '2023-10-10',
        startTime: '07:00',
        endTime: '09:00'
      }
    ],
    reviews: [
      {
        userId: 'user1',
        rating: 5,
        comment: 'The guide was very knowledgeable and we saw so much wildlife! Highly recommend.',
        date: '2023-07-30'
      }
    ],
    createdAt: '2023-06-15',
    updatedAt: '2023-08-12'
  }
];

// Mock Bookings
export const bookings = [
  {
    id: 'book1',
    userId: 'user1',
    itemType: 'stay', // stay or experience
    itemId: 'stay1',
    startDate: '2023-09-10',
    endDate: '2023-09-12',
    guests: 2,
    totalAmount: 5000,
    currency: 'INR',
    status: 'confirmed', // confirmed, pending, cancelled, completed
    paymentStatus: 'paid', // paid, pending
    createdAt: '2023-08-01',
    updatedAt: '2023-08-01'
  },
  {
    id: 'book2',
    userId: 'user1',
    itemType: 'experience',
    itemId: 'exp1',
    date: '2023-09-15',
    participants: 2,
    totalAmount: 2400,
    currency: 'INR',
    status: 'confirmed',
    paymentStatus: 'paid',
    createdAt: '2023-08-05',
    updatedAt: '2023-08-05'
  }
];

// Mock Reviews
export const reviews = [
  {
    id: 'rev1',
    userId: 'user1',
    itemType: 'stay',
    itemId: 'stay1',
    rating: 5,
    comment: 'Amazing experience with beautiful views and great hospitality.',
    date: '2023-07-15'
  },
  {
    id: 'rev2',
    userId: 'user1',
    itemType: 'experience',
    itemId: 'exp1',
    rating: 5,
    comment: 'Very informative workshop with hands-on activities. Great for beginners!',
    date: '2023-08-02'
  }
];

// Export a combined object for easier imports
export const mockData = {
  users,
  stays,
  experiences,
  bookings,
  reviews
};

export default mockData;
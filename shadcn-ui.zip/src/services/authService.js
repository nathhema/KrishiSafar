// Authentication service using mock data
import { users } from './mockData';

// Simulate API delay
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// Authentication service
const authService = {
  // Login user
  async login(email, password) {
    await delay(800); // Simulate API delay
    
    // Find user with matching credentials
    const user = users.find(
      (u) => u.email.toLowerCase() === email.toLowerCase() && u.password === password
    );
    
    if (user) {
      // Create a simplified user object (without password)
      const authUser = {
        id: user.id,
        email: user.email,
        name: user.name,
        type: user.type,
        profilePic: user.profilePic || null,
      };
      
      // In a real app, we would receive a token from the backend
      const mockToken = btoa(JSON.stringify({ id: user.id, email: user.email }));
      
      // Store the user and token in localStorage
      localStorage.setItem('krishiSafarToken', mockToken);
      localStorage.setItem('krishiSafarUser', JSON.stringify(authUser));
      
      return { user: authUser, token: mockToken };
    } else {
      throw new Error('Invalid email or password');
    }
  },
  
  // Register new user
  async register(userData) {
    await delay(1000); // Simulate API delay
    
    // Check if user with email already exists
    const existingUser = users.find(
      (u) => u.email.toLowerCase() === userData.email.toLowerCase()
    );
    
    if (existingUser) {
      throw new Error('Email already in use');
    }
    
    // In a real app, this would be handled by the backend
    const newUser = {
      id: `user${users.length + 1}`,
      ...userData,
      type: userData.type || 'user', // Default to regular user if not specified
      createdAt: new Date().toISOString()
    };
    
    // In a real app, we would add the user to the database
    // For now, we just return the new user
    
    // Create a simplified user object (without password)
    const authUser = {
      id: newUser.id,
      email: newUser.email,
      name: newUser.name,
      type: newUser.type,
      profilePic: newUser.profilePic || null,
    };
    
    // In a real app, we would receive a token from the backend
    const mockToken = btoa(JSON.stringify({ id: newUser.id, email: newUser.email }));
    
    // Store the user and token in localStorage
    localStorage.setItem('krishiSafarToken', mockToken);
    localStorage.setItem('krishiSafarUser', JSON.stringify(authUser));
    
    return { user: authUser, token: mockToken };
  },
  
  // Check if user is logged in
  isAuthenticated() {
    const token = localStorage.getItem('krishiSafarToken');
    const user = localStorage.getItem('krishiSafarUser');
    return !!(token && user);
  },
  
  // Get current user
  getCurrentUser() {
    const userStr = localStorage.getItem('krishiSafarUser');
    if (userStr) {
      try {
        return JSON.parse(userStr);
      } catch (e) {
        return null;
      }
    }
    return null;
  },
  
  // Logout user
  logout() {
    localStorage.removeItem('krishiSafarToken');
    localStorage.removeItem('krishiSafarUser');
  },
  
  // Get user role
  getUserRole() {
    const user = this.getCurrentUser();
    return user ? user.type : null;
  }
};

export default authService;